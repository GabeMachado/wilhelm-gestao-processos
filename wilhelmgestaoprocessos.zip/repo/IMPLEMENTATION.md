# Wilhelm · Gestão de Processos — Implementation

Full-stack implementation of the `Wilhelm - Gestão de Processos.dc.html` design
(see `README.md` and `chats/` for the original design brief and iteration history).

## Stack

- **Frontend**: React + TypeScript + Vite, React Router, no CSS framework (styles
  ported 1:1 from the design's inline styles / tokens: dark theme, gold accent
  `#d6a52a`, Geist font).
- **Backend**: Node.js + Express + TypeScript.
- **Database**: PostgreSQL + Prisma ORM.
- **Auth**: real authentication — bcrypt-hashed passwords, JWT in an httpOnly
  cookie, server-side permission checks per role (Administrador, Advogado,
  Assistente, Financeiro) matching the matrix on the Equipe screen.

## Project layout

```
server/         Express API, Prisma schema + seed, business logic
  src/app.ts      the configured Express app (exported, no listen())
  src/index.ts    local-dev entry: imports app.ts and calls listen()
client/         React app (Vite)
api/index.ts    Vercel serverless entry — imports server/src/app.ts as-is
vercel.json     build/output config + rewrites (see DEPLOY.md)
package.json    root npm workspaces (client, server) so Vercel can resolve
                both packages' dependencies from one install
docker-compose.yml   Postgres for local dev (optional — see below)
```

This repo runs as one Express app in two contexts: a normal long-running
process locally (`server/src/index.ts`), and a single Vercel serverless
function in production (`api/index.ts`) — same `app.ts`, no duplicated
logic. See **`DEPLOY.md`** for the GitHub → Supabase → Vercel deployment
steps.

## Running locally

### 1. Install (run once, from the repo root — it's an npm workspace)

```
npm install
```

### 2. Database

Either run Postgres via Docker:

```
docker compose up -d
```

...or point `DATABASE_URL` at any Postgres instance you already have (the dev
environment used to build this had Postgres installed natively — see
`server/.env.example`).

### 3. Backend

```
cd server
cp .env.example .env   # adjust DATABASE_URL/DIRECT_URL/JWT_SECRET if needed
npx prisma migrate dev --name init
npx tsx prisma/seed.ts
npm run dev              # http://localhost:4000
```

### 4. Frontend

```
cd client
npm run dev               # http://localhost:5173 (proxies /api to :4000)
```

### Demo login

Any seeded e-mail (e.g. `camila@wilhelm.adv.br`) with password `senha-demo`.
Seeded users cover all four roles — see `server/prisma/seed.ts`.

## What's implemented

Matches the scoped-down "núcleo" from the design chats:

- Login (real auth), sidebar/topbar shell, command palette (⌘K), notifications,
  toasts.
- Dashboard: metric cards, pendências, funnel/donut/bar charts, prazos,
  atividade recente — all served by `GET /api/dashboard`.
- Processos: Lista (table + filters + search), Kanban (drag & drop → `POST
  /processos/:id/move`), Timeline (swimlanes).
- Process detail: header + stepper + "Concluir etapa" (`POST
  /processos/:id/advance`), tabs (Dados Gerais, Fluxo, Histórico, Observações).
- Create / edit (drawer) / delete (confirm dialog) — all permission-gated.
- Import: upload a real `.xlsx`, auto-detects the header row (real-world
  spreadsheets often have summary rows above the actual header) and maps
  columns by best-effort alias matching. Export: CSV download.
- Equipe & Permissões: role summary, team members, read-only permissions
  matrix sourced from `server/src/permissions.ts` (the single source of truth
  also enforced server-side on every mutating route).
- Calendário / Relatórios / Configurações: present in navigation but
  intentionally left blank, matching the original design exactly (they were
  never designed beyond the nav entry).

## Notes

- The permission matrix is enforced **server-side** (`requirePermission` in
  `server/src/auth.ts`) — the frontend only uses it to hide/show UI, it isn't
  the security boundary.
- Historico entries double as the per-process audit trail (who/when/what),
  matching what was actually designed — there's no separate global audit log
  screen since one was never designed.
