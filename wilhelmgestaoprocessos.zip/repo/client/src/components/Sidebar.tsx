import { useLocation, useNavigate } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useAuth } from '../context/AuthContext';
import { useProcesses } from '../context/ProcessesContext';

const ROLE_LABEL: Record<string, string> = {
  ADMIN: 'Administrador(a)',
  ADVOGADO: 'Advogado(a)',
  ASSISTENTE: 'Assistente',
  FINANCEIRO: 'Financeiro',
};

const NAV = [
  { path: '/dashboard', label: 'Dashboard', icon: 'dashboard' },
  { path: '/processos', label: 'Processos', icon: 'list', withBadge: true },
  { path: '/processos/kanban', label: 'Kanban', icon: 'columns' },
  { path: '/processos/timeline', label: 'Timeline', icon: 'layers' },
  { path: '/calendario', label: 'Calendário', icon: 'calendar' },
  { path: '/relatorios', label: 'Relatórios', icon: 'bars' },
  { path: '/equipe', label: 'Equipe', icon: 'users' },
  { path: '/configuracoes', label: 'Configurações', icon: 'settings' },
];

export default function Sidebar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { processes } = useProcesses();

  function isActive(path: string) {
    if (path === '/processos') return pathname === '/processos' || pathname.startsWith('/processos/') && !pathname.startsWith('/processos/kanban') && !pathname.startsWith('/processos/timeline');
    return pathname === path || pathname.startsWith(path + '/');
  }

  async function handleLogout() {
    await logout();
    navigate('/login');
  }

  return (
    <aside style={{ background: '#0c0d11', borderRight: '1px solid rgba(255,255,255,.06)', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div style={{ padding: '20px 18px 16px', display: 'flex', alignItems: 'center', gap: 11, borderBottom: '1px solid rgba(255,255,255,.05)' }}>
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 9,
            background: 'linear-gradient(150deg,var(--accent),#a97c14)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#1a1400',
            boxShadow: '0 2px 10px rgba(214,165,42,.28)',
          }}
        >
          <Icon name="scale" size={19} sw={2} />
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: 14.5, letterSpacing: '.2px' }}>Wilhelm</div>
          <div style={{ fontSize: 10.5, color: '#6f7480', letterSpacing: '.5px', textTransform: 'uppercase', marginTop: 1 }}>
            Advogados · Tributário
          </div>
        </div>
      </div>

      <div style={{ padding: '12px 12px 4px', fontSize: 10, fontWeight: 600, letterSpacing: '.8px', textTransform: 'uppercase', color: '#5b6069' }}>
        Operação
      </div>
      <nav style={{ padding: '2px 10px', display: 'flex', flexDirection: 'column', gap: 2, overflowY: 'auto', flex: 1, minHeight: 0 }}>
        {NAV.map((n) => {
          const active = isActive(n.path);
          return (
            <button
              key={n.path}
              className="nav-item btn"
              onClick={() => navigate(n.path)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 11,
                padding: '8px 10px',
                borderRadius: 8,
                color: active ? 'var(--accent)' : '#a4a9b4',
                background: active ? 'var(--accent-bg)' : 'transparent',
                fontWeight: active ? 600 : 450,
                fontSize: 13.5,
                textAlign: 'left',
              }}
            >
              <Icon name={n.icon} size={17} />
              <span style={{ flex: 1 }}>{n.label}</span>
              {n.withBadge && (
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: active ? 'var(--accent)' : '#8b909c',
                    background: 'rgba(255,255,255,.06)',
                    minWidth: 20,
                    textAlign: 'center',
                    padding: '1px 6px',
                    borderRadius: 20,
                  }}
                >
                  {processes.length}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div style={{ padding: 12, borderTop: '1px solid rgba(255,255,255,.05)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 8, borderRadius: 9 }}>
          {user && (
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                background: 'var(--accent-bg)',
                color: 'var(--accent)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              {user.initials}
            </div>
          )}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.nome}
            </div>
            <div style={{ fontSize: 10.5, color: '#6f7480' }}>{user ? ROLE_LABEL[user.role] : ''}</div>
          </div>
          <button
            onClick={handleLogout}
            title="Sair"
            className="btn"
            style={{ width: 30, height: 30, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#6f7480' }}
          >
            <Icon name="logout" size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
}
