import { useNavigate } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useProcesses } from '../context/ProcessesContext';
import { useUI } from '../context/UIContext';
import { daysBetween, emeta, fmtDate } from '../lib/format';

export default function NotificationsDropdown() {
  const { processes } = useProcesses();
  const { closeNotif } = useUI();
  const navigate = useNavigate();
  const now = new Date();

  const notifications = processes
    .filter((p) => emeta(p.etapa) && p.prazo && p.etapa !== 'ENCERRADO')
    .map((p) => ({ p, dias: daysBetween(new Date(p.prazo as string), now) }))
    .sort((a, b) => a.dias - b.dias)
    .slice(0, 5)
    .map(({ p, dias }) => {
      const over = dias < 0;
      return {
        pid: p.id,
        icon: over ? 'alert' : 'clock',
        color: over ? '#e5644e' : '#e0a53a',
        bg: over ? 'rgba(229,100,78,.14)' : 'rgba(224,165,58,.14)',
        text: over ? `Prazo vencido há ${Math.abs(dias)} dias` : `Prazo em ${dias} dias · ${p.proximaAcao}`,
        cliente: p.cliente,
        when: fmtDate(p.prazo),
      };
    });

  return (
    <div
      className="anim-pop"
      style={{
        position: 'absolute',
        top: 42,
        right: 0,
        width: 340,
        background: '#131418',
        border: '1px solid rgba(255,255,255,.1)',
        borderRadius: 13,
        boxShadow: '0 18px 50px rgba(0,0,0,.55)',
        zIndex: 60,
        overflow: 'hidden',
      }}
    >
      <div style={{ padding: '13px 15px', borderBottom: '1px solid rgba(255,255,255,.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontWeight: 600, fontSize: 13.5 }}>Notificações</span>
        <span style={{ fontSize: 11, color: 'var(--accent)' }}>{notifications.length} novas</span>
      </div>
      <div style={{ maxHeight: 360, overflowY: 'auto' }}>
        {notifications.length === 0 && (
          <div style={{ padding: 24, textAlign: 'center', fontSize: 12.5, color: '#6f7480' }}>Nenhuma notificação pendente.</div>
        )}
        {notifications.map((n) => (
          <div
            key={n.pid}
            className="row-hover"
            onClick={() => {
              closeNotif();
              navigate(`/processos/${n.pid}`);
            }}
            style={{ display: 'flex', gap: 11, padding: '12px 15px', borderBottom: '1px solid rgba(255,255,255,.04)', cursor: 'pointer' }}
          >
            <div style={{ width: 30, height: 30, flex: 'none', borderRadius: 8, background: n.bg, color: n.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={n.icon} size={15} />
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>{n.text}</div>
              <div style={{ fontSize: 11, color: '#6f7480', marginTop: 2 }}>
                {n.cliente} · {n.when}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
