import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useUI } from '../context/UIContext';
import { useProcesses } from '../context/ProcessesContext';
import { useToast } from '../context/ToastContext';
import { api, ApiError } from '../lib/api';

export default function ConfirmDialog() {
  const { confirmDeleteId, cancelDelete } = useUI();
  const { processes, removeLocal } = useProcesses();
  const flash = useToast();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  if (!confirmDeleteId) return null;
  const processo = processes.find((p) => p.id === confirmDeleteId);

  async function handleDelete() {
    setBusy(true);
    try {
      await api.delete(`/processos/${confirmDeleteId}`);
      removeLocal(confirmDeleteId!);
      cancelDelete();
      flash('Processo excluído e registrado na auditoria', 'danger');
      navigate('/processos');
    } catch (err) {
      flash(err instanceof ApiError ? err.message : 'Não foi possível excluir', 'warn');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      onClick={cancelDelete}
      className="anim-fade"
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.6)', zIndex: 95, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, backdropFilter: 'blur(3px)' }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="anim-pop"
        style={{ width: 420, maxWidth: '100%', background: '#111318', border: '1px solid rgba(255,255,255,.1)', borderRadius: 15, padding: 24, boxShadow: '0 30px 80px rgba(0,0,0,.6)' }}
      >
        <div style={{ width: 42, height: 42, borderRadius: 11, background: 'rgba(229,100,78,.14)', color: '#e5644e', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 15 }}>
          <Icon name="alert" size={22} />
        </div>
        <h2 style={{ marginBottom: 7, fontSize: 17, fontWeight: 600 }}>Excluir processo?</h2>
        <p style={{ marginBottom: 20, fontSize: 13, color: '#a4a9b4', lineHeight: 1.55 }}>
          O processo <b style={{ color: 'var(--text)' }}>{processo?.cliente}</b> e todo o seu histórico serão removidos. Esta ação será
          registrada na auditoria e não pode ser desfeita.
        </p>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button onClick={cancelDelete} className="btn" style={{ height: 37, padding: '0 16px', borderRadius: 9, border: '1px solid rgba(255,255,255,.12)', color: '#c3c7ce', fontSize: 13, fontWeight: 500 }}>
            Cancelar
          </button>
          <button
            onClick={handleDelete}
            disabled={busy}
            className="btn"
            style={{ display: 'flex', alignItems: 'center', gap: 7, height: 37, padding: '0 16px', borderRadius: 9, background: '#e5644e', color: '#fff', fontWeight: 600, fontSize: 13, opacity: busy ? 0.7 : 1 }}
          >
            {busy ? <span className="spinner" /> : <Icon name="trash" size={15} />}
            Excluir
          </button>
        </div>
      </div>
    </div>
  );
}
