import { useEffect, useState, type ChangeEvent, type CSSProperties, type ReactNode } from 'react';
import { Icon } from '../lib/icons';
import { useUI } from '../context/UIContext';
import { useProcesses } from '../context/ProcessesContext';
import { useToast } from '../context/ToastContext';
import { api, ApiError } from '../lib/api';
import { toIsoDateInput } from '../lib/format';
import type { Etapa, Processo } from '../lib/types';

interface FormState {
  cliente: string;
  cnpj: string;
  numero: string;
  tipo: string;
  advId: string;
  tese: string;
  tribunal: string;
  cidade: string;
  estado: string;
  etapa: Etapa;
  dataEntrada: string;
  proximaAcao: string;
  prazo: string;
  valorCausa: string;
  valorCredito: string;
  observacoes: string;
}

const EMPTY: FormState = {
  cliente: '',
  cnpj: '',
  numero: '',
  tipo: 'Mandado de Segurança',
  advId: '',
  tese: '',
  tribunal: '',
  cidade: '',
  estado: 'SC',
  etapa: 'ENTRADA',
  dataEntrada: toIsoDateInput(new Date()),
  proximaAcao: 'Cadastrar no sistema e dar CCR',
  prazo: '',
  valorCausa: '',
  valorCredito: '',
  observacoes: '',
};

function fromProcesso(p: Processo): FormState {
  return {
    cliente: p.cliente,
    cnpj: p.cnpj,
    numero: p.numero,
    tipo: p.tipo,
    advId: p.advId,
    tese: p.tese,
    tribunal: p.tribunal,
    cidade: p.cidade,
    estado: p.estado,
    etapa: p.etapa,
    dataEntrada: toIsoDateInput(p.dataEntrada),
    proximaAcao: p.proximaAcao,
    prazo: toIsoDateInput(p.prazo),
    valorCausa: String(p.valorCausa || ''),
    valorCredito: String(p.valorCredito || ''),
    observacoes: p.observacoes,
  };
}

interface Advogado {
  id: string;
  nome: string;
}

export default function Drawer() {
  const { drawer, closeDrawer } = useUI();
  const { upsertLocal, refresh } = useProcesses();
  const flash = useToast();
  const [form, setForm] = useState<FormState>(EMPTY);
  const [advogados, setAdvogados] = useState<Advogado[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!drawer) return;
    api
      .get<{ team: Advogado[] }>('/users')
      .then((data) => setAdvogados(data.team))
      .catch(() => setAdvogados([]));
    setError('');
    if (drawer.mode === 'edit') {
      const f = fromProcesso(drawer.processo);
      setForm(f);
    } else {
      setForm({ ...EMPTY, dataEntrada: toIsoDateInput(new Date()) });
    }
  }, [drawer]);

  if (!drawer) return null;

  function field(name: keyof FormState) {
    return (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      setForm((f) => ({ ...f, [name]: e.target.value }));
    };
  }

  async function handleSave() {
    if (!drawer) return;
    if (!form.cliente.trim()) {
      setError('Informe o cliente');
      return;
    }
    if (!form.advId) {
      setError('Selecione o advogado responsável');
      return;
    }
    setSaving(true);
    setError('');
    const payload = { ...form, prazo: form.prazo || null };
    try {
      let saved: Processo;
      if (drawer.mode === 'edit') {
        saved = await api.patch<Processo>(`/processos/${drawer.processo.id}`, payload);
        flash('Processo atualizado');
      } else {
        saved = await api.post<Processo>('/processos', payload);
        flash('Processo cadastrado com sucesso');
      }
      upsertLocal(saved);
      await refresh();
      closeDrawer();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Não foi possível salvar');
    } finally {
      setSaving(false);
    }
  }

  const title = drawer.mode === 'edit' ? 'Editar processo' : 'Novo processo';
  const sub = drawer.mode === 'edit' ? 'Atualize os dados e o andamento do fluxo' : 'Cadastre um novo processo na carteira';
  const cta = drawer.mode === 'edit' ? 'Salvar alterações' : 'Cadastrar processo';

  const labelStyle: CSSProperties = { display: 'flex', flexDirection: 'column', gap: 5, fontSize: 12, color: '#a4a9b4' };
  const inputStyle: CSSProperties = { height: 36, padding: '0 11px', fontSize: 13 };

  return (
    <>
      <div onClick={closeDrawer} className="anim-fade" style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.55)', zIndex: 80, backdropFilter: 'blur(2px)' }} />
      <div
        className="anim-drawer"
        style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: 560,
          maxWidth: '94vw',
          background: '#101116',
          borderLeft: '1px solid rgba(255,255,255,.09)',
          zIndex: 81,
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '-20px 0 60px rgba(0,0,0,.5)',
        }}
      >
        <div style={{ padding: '18px 22px', borderBottom: '1px solid rgba(255,255,255,.07)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flex: 'none' }}>
          <div>
            <h2 style={{ fontSize: 16, fontWeight: 600 }}>{title}</h2>
            <p style={{ marginTop: 3, fontSize: 12, color: '#8b909c' }}>{sub}</p>
          </div>
          <button onClick={closeDrawer} className="btn" style={{ width: 32, height: 32, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#8b909c' }}>
            <Icon name="x" size={18} />
          </button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: 22, display: 'flex', flexDirection: 'column', gap: 22 }}>
          {error && (
            <div style={{ fontSize: 12.5, color: '#e5644e', background: 'rgba(229,100,78,.1)', border: '1px solid rgba(229,100,78,.25)', borderRadius: 8, padding: '9px 11px' }}>
              {error}
            </div>
          )}

          <div>
            <SectionLabel>Dados gerais</SectionLabel>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13 }}>
              <label style={{ ...labelStyle, gridColumn: 'span 2' }}>
                <span>Cliente</span>
                <input className="text-input" style={inputStyle} value={form.cliente} onChange={field('cliente')} placeholder="Razão social" />
              </label>
              <label style={labelStyle}>
                <span>CNPJ / CPF</span>
                <input className="text-input" style={inputStyle} value={form.cnpj} onChange={field('cnpj')} placeholder="00.000.000/0001-00" />
              </label>
              <label style={labelStyle}>
                <span>Número (CNJ)</span>
                <input className="text-input" style={{ ...inputStyle, fontFamily: "'Geist Mono',monospace" }} value={form.numero} onChange={field('numero')} placeholder="0000000-00.0000.0.00.0000" />
              </label>
              <label style={labelStyle}>
                <span>Tipo</span>
                <select className="text-input" style={{ ...inputStyle, cursor: 'pointer' }} value={form.tipo} onChange={field('tipo')}>
                  <option>Mandado de Segurança</option>
                  <option>Cumprimento de Sentença</option>
                  <option>Ação Ordinária</option>
                  <option>Ação Declaratória</option>
                </select>
              </label>
              <label style={labelStyle}>
                <span>Advogado responsável</span>
                <select className="text-input" style={{ ...inputStyle, cursor: 'pointer' }} value={form.advId} onChange={field('advId')}>
                  <option value="">Selecione…</option>
                  {advogados.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.nome}
                    </option>
                  ))}
                </select>
              </label>
              <label style={{ ...labelStyle, gridColumn: 'span 2' }}>
                <span>Tese / Título</span>
                <input className="text-input" style={inputStyle} value={form.tese} onChange={field('tese')} placeholder="Ex.: PIS/COFINS – Exclusão do ICMS da base de cálculo" />
              </label>
              <label style={labelStyle}>
                <span>Tribunal / Vara</span>
                <input className="text-input" style={inputStyle} value={form.tribunal} onChange={field('tribunal')} placeholder="TRF4 · 1ª Vara Federal" />
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 10 }}>
                <label style={labelStyle}>
                  <span>Cidade</span>
                  <input className="text-input" style={inputStyle} value={form.cidade} onChange={field('cidade')} placeholder="Blumenau" />
                </label>
                <label style={labelStyle}>
                  <span>UF</span>
                  <input className="text-input" style={inputStyle} value={form.estado} onChange={field('estado')} placeholder="SC" />
                </label>
              </div>
            </div>
          </div>

          <div>
            <SectionLabel>Situação & fluxo</SectionLabel>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13 }}>
              <label style={labelStyle}>
                <span>Etapa atual</span>
                <select className="text-input" style={{ ...inputStyle, cursor: 'pointer' }} value={form.etapa} onChange={field('etapa')}>
                  <option value="ENTRADA">Entrada</option>
                  <option value="DOCUMENTOS">Documentos & Procuração</option>
                  <option value="HABILITACAO">Habilitação</option>
                  <option value="COMPENSACAO">Compensação</option>
                  <option value="HONORARIOS">Honorários</option>
                  <option value="ENCERRADO">Encerrado</option>
                </select>
              </label>
              <label style={labelStyle}>
                <span>Data de entrada</span>
                <input type="date" className="text-input" style={{ ...inputStyle, colorScheme: 'dark' }} value={form.dataEntrada} onChange={field('dataEntrada')} />
              </label>
              <label style={{ ...labelStyle, gridColumn: 'span 2' }}>
                <span>Próxima ação</span>
                <input className="text-input" style={inputStyle} value={form.proximaAcao} onChange={field('proximaAcao')} placeholder="Ex.: Cobrar procuração assinada" />
              </label>
              <label style={labelStyle}>
                <span>Prazo</span>
                <input type="date" className="text-input" style={{ ...inputStyle, colorScheme: 'dark' }} value={form.prazo} onChange={field('prazo')} />
              </label>
            </div>
          </div>

          <div>
            <SectionLabel>Financeiro & observações</SectionLabel>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13 }}>
              <label style={labelStyle}>
                <span>Valor da causa (R$)</span>
                <input className="text-input" style={{ ...inputStyle, fontVariantNumeric: 'tabular-nums' }} value={form.valorCausa} onChange={field('valorCausa')} placeholder="0,00" />
              </label>
              <label style={labelStyle}>
                <span>Valor do crédito (R$)</span>
                <input className="text-input" style={{ ...inputStyle, fontVariantNumeric: 'tabular-nums' }} value={form.valorCredito} onChange={field('valorCredito')} placeholder="0,00" />
              </label>
              <label style={{ ...labelStyle, gridColumn: 'span 2' }}>
                <span>Observações</span>
                <textarea
                  className="text-input"
                  style={{ minHeight: 76, padding: '10px 11px', resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.5, fontSize: 13 }}
                  value={form.observacoes}
                  onChange={field('observacoes')}
                  placeholder="Anotações internas sobre o andamento…"
                />
              </label>
            </div>
          </div>
        </div>

        <div style={{ padding: '15px 22px', borderTop: '1px solid rgba(255,255,255,.07)', display: 'flex', gap: 10, justifyContent: 'flex-end', flex: 'none' }}>
          <button onClick={closeDrawer} className="btn" style={{ height: 37, padding: '0 16px', borderRadius: 9, border: '1px solid rgba(255,255,255,.12)', color: '#c3c7ce', fontSize: 13, fontWeight: 500 }}>
            Cancelar
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="btn btn-accent"
            style={{ display: 'flex', alignItems: 'center', gap: 7, height: 37, padding: '0 18px', borderRadius: 9, background: 'var(--accent)', color: 'var(--accent-fg)', fontWeight: 600, fontSize: 13, opacity: saving ? 0.7 : 1 }}
          >
            {saving ? <span className="spinner" /> : <Icon name="check" size={16} sw={2.4} />}
            {cta}
          </button>
        </div>
      </div>
    </>
  );
}

function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 13 }}>
      {children}
    </div>
  );
}
