import { useNavigate } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useProcesses } from '../context/ProcessesContext';
import { useUI } from '../context/UIContext';
import { useCan } from '../context/AuthContext';
import { api } from '../lib/api';

const SUB_TABS = [
  { key: 'lista', label: 'Lista', icon: 'list', path: '/processos' },
  { key: 'kanban', label: 'Kanban', icon: 'columns', path: '/processos/kanban' },
  { key: 'timeline', label: 'Timeline', icon: 'layers', path: '/processos/timeline' },
];

export default function ProcessosHeader({ active }: { active: 'lista' | 'kanban' | 'timeline' }) {
  const navigate = useNavigate();
  const { processes, filtered, filters, setFilters, clearFilters } = useProcesses();
  const { openImport } = useUI();
  const canImportExport = useCan('IMPORT_EXPORT');
  const advogados = Array.from(new Set(processes.map((p) => p.adv))).sort();
  const hasFilters = !!(filters.etapa || filters.resp || filters.tipo || filters.status || filters.search);

  async function handleExport() {
    const blob = await api.get<Blob>('/export');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'processos-wilhelm.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div style={{ padding: '20px 28px 0', flex: 'none' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-.3px' }}>Processos</h1>
          <p style={{ marginTop: 4, color: '#8b909c', fontSize: 13 }}>
            {processes.length} processos · {filtered.length} exibidos
          </p>
        </div>
        {canImportExport && (
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={openImport}
              className="btn"
              style={{ display: 'flex', alignItems: 'center', gap: 7, height: 34, padding: '0 13px', borderRadius: 9, border: '1px solid rgba(255,255,255,.1)', color: '#c3c7ce', fontSize: 12.5, fontWeight: 500 }}
            >
              <Icon name="upload" size={15} />
              Importar
            </button>
            <button
              onClick={handleExport}
              className="btn"
              style={{ display: 'flex', alignItems: 'center', gap: 7, height: 34, padding: '0 13px', borderRadius: 9, border: '1px solid rgba(255,255,255,.1)', color: '#c3c7ce', fontSize: 12.5, fontWeight: 500 }}
            >
              <Icon name="download" size={15} />
              Exportar
            </button>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 14, borderBottom: '1px solid rgba(255,255,255,.07)' }}>
        {SUB_TABS.map((t) => {
          const isActive = t.key === active;
          return (
            <button
              key={t.key}
              onClick={() => navigate(t.path)}
              className="btn"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 7,
                padding: '9px 2px 11px',
                fontSize: 13,
                fontWeight: isActive ? 600 : 450,
                color: isActive ? 'var(--text)' : '#8b909c',
                borderBottom: `2px solid ${isActive ? 'var(--accent)' : 'transparent'}`,
                marginBottom: -1,
              }}
            >
              <Icon name={t.icon} size={15} />
              {t.label}
            </button>
          );
        })}
      </div>

      <div style={{ padding: '13px 0', display: 'flex', alignItems: 'center', gap: 9, flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 220, maxWidth: 340 }}>
          <span style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: '#6f7480' }}>
            <Icon name="search" size={15} />
          </span>
          <input
            value={filters.search}
            onChange={(e) => setFilters({ search: e.target.value })}
            placeholder="Buscar por cliente, número, CNPJ, tese…"
            className="text-input"
            style={{ height: 34, padding: '0 12px 0 34px', fontSize: 13 }}
          />
        </div>
        <select value={filters.etapa} onChange={(e) => setFilters({ etapa: e.target.value as never })} className="text-input" style={{ height: 34, padding: '0 10px', fontSize: 12.5, cursor: 'pointer', width: 'auto' }}>
          <option value="">Etapa: todas</option>
          <option value="ENTRADA">Entrada</option>
          <option value="DOCUMENTOS">Documentos</option>
          <option value="HABILITACAO">Habilitação</option>
          <option value="COMPENSACAO">Compensação</option>
          <option value="HONORARIOS">Honorários</option>
          <option value="ENCERRADO">Encerrado</option>
        </select>
        <select value={filters.resp} onChange={(e) => setFilters({ resp: e.target.value })} className="text-input" style={{ height: 34, padding: '0 10px', fontSize: 12.5, cursor: 'pointer', width: 'auto' }}>
          <option value="">Responsável: todos</option>
          {advogados.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </select>
        <select value={filters.tipo} onChange={(e) => setFilters({ tipo: e.target.value })} className="text-input" style={{ height: 34, padding: '0 10px', fontSize: 12.5, cursor: 'pointer', width: 'auto' }}>
          <option value="">Tipo: todos</option>
          <option>Mandado de Segurança</option>
          <option>Cumprimento de Sentença</option>
          <option>Ação Ordinária</option>
          <option>Ação Declaratória</option>
        </select>
        <select value={filters.status} onChange={(e) => setFilters({ status: e.target.value })} className="text-input" style={{ height: 34, padding: '0 10px', fontSize: 12.5, cursor: 'pointer', width: 'auto' }}>
          <option value="">Status: todos</option>
          <option value="ATIVO">Ativo</option>
          <option value="ARQUIVADO">Arquivado</option>
        </select>
        {hasFilters && (
          <button onClick={clearFilters} className="btn" style={{ height: 34, padding: '0 11px', borderRadius: 9, color: 'var(--accent)', fontSize: 12.5, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 5 }}>
            <Icon name="x" size={14} />
            Limpar
          </button>
        )}
      </div>
    </div>
  );
}
