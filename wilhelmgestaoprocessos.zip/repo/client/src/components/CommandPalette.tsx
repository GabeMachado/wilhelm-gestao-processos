import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useUI } from '../context/UIContext';
import { useProcesses } from '../context/ProcessesContext';
import { emeta } from '../lib/format';

export default function CommandPalette() {
  const { commandOpen, closeCommand } = useUI();
  const { processes } = useProcesses();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (commandOpen) {
      setQuery('');
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  }, [commandOpen]);

  if (!commandOpen) return null;

  const q = query.trim().toLowerCase();
  let results: { key: string; icon: string; color: string; bg: string; title: string; sub: string; kind: string; go: () => void }[] = [];

  if (q) {
    results = processes
      .filter((p) => `${p.cliente} ${p.numero} ${p.cnpj} ${p.pasta} ${p.tese}`.toLowerCase().includes(q))
      .slice(0, 6)
      .map((p) => {
        const em = emeta(p.etapa);
        return {
          key: p.id,
          icon: 'folder',
          color: em.color,
          bg: em.bg,
          title: p.cliente,
          sub: `${p.pasta} · ${em.label}`,
          kind: 'Processo',
          go: () => navigate(`/processos/${p.id}`),
        };
      });
  } else {
    results = [
      { key: 'dash', icon: 'dashboard', color: '#5b8def', bg: 'rgba(91,141,239,.14)', title: 'Ir para Dashboard', sub: 'Visão geral', kind: 'Ação', go: () => navigate('/dashboard') },
      { key: 'proc', icon: 'list', color: '#8b7bd8', bg: 'rgba(139,123,216,.14)', title: 'Ver todos os processos', sub: `${processes.length} processos`, kind: 'Ação', go: () => navigate('/processos') },
      { key: 'kanban', icon: 'columns', color: '#3bc0c8', bg: 'rgba(59,192,200,.14)', title: 'Abrir Kanban', sub: 'Fluxo por etapa', kind: 'Ação', go: () => navigate('/processos/kanban') },
    ];
  }

  function pick(r: (typeof results)[number]) {
    r.go();
    closeCommand();
  }

  return (
    <div
      onClick={closeCommand}
      className="anim-fade"
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.5)', zIndex: 100, display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: '12vh' }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="anim-pop"
        style={{ width: 600, maxWidth: '92vw', background: '#131418', border: '1px solid rgba(255,255,255,.12)', borderRadius: 14, boxShadow: '0 30px 90px rgba(0,0,0,.65)', overflow: 'hidden' }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '15px 18px', borderBottom: '1px solid rgba(255,255,255,.07)' }}>
          <Icon name="search" size={18} style={{ color: '#6f7480' }} />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Escape' && closeCommand()}
            placeholder="Buscar processos, clientes ou ações…"
            style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: 'var(--text)', fontSize: 15 }}
          />
          <span style={{ fontFamily: "'Geist Mono',monospace", fontSize: 11, border: '1px solid rgba(255,255,255,.12)', borderRadius: 5, padding: '2px 6px', color: '#6f7480' }}>esc</span>
        </div>
        <div style={{ maxHeight: 400, overflowY: 'auto', padding: 8 }}>
          {results.map((r) => (
            <div
              key={r.key}
              onClick={() => pick(r)}
              className="row-hover"
              style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 9, cursor: 'pointer' }}
            >
              <div style={{ width: 30, height: 30, flex: 'none', borderRadius: 8, background: r.bg, color: r.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={r.icon} size={15} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.title}</div>
                <div style={{ fontSize: 11.5, color: '#6f7480' }}>{r.sub}</div>
              </div>
              <span style={{ fontSize: 10.5, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.4px' }}>{r.kind}</span>
            </div>
          ))}
          {q && results.length === 0 && (
            <div style={{ padding: 36, textAlign: 'center', color: '#6f7480', fontSize: 13 }}>Nenhum resultado para "{query}"</div>
          )}
        </div>
      </div>
    </div>
  );
}
