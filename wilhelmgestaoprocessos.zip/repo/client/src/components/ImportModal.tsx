import { useRef, useState } from 'react';
import { Icon } from '../lib/icons';
import { useUI } from '../context/UIContext';
import { useProcesses } from '../context/ProcessesContext';
import { useToast } from '../context/ToastContext';
import { api, ApiError } from '../lib/api';

const COLUMN_MAP = [
  { col: 'PASTA', field: 'Pasta / Referência' },
  { col: 'NÚMERO', field: 'Número CNJ' },
  { col: 'CLIENTE', field: 'Cliente' },
  { col: 'TÍTULO', field: 'Tese / Título' },
  { col: 'TIPO', field: 'Tipo de processo' },
  { col: 'STATUS / FASE', field: 'Etapa do fluxo' },
  { col: 'VALOR DA CAUSA', field: 'Valor da causa' },
  { col: 'VALOR HABILITADO', field: 'Valor habilitado' },
];

export default function ImportModal() {
  const { importOpen, closeImport } = useUI();
  const { refresh } = useProcesses();
  const flash = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  if (!importOpen) return null;

  async function handleConfirm() {
    if (!file) {
      setError('Selecione um arquivo .xlsx para importar');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await api.upload<{ imported: number }>('/import', fd);
      await refresh();
      flash(`${res.imported} processos importados da planilha`);
      closeImport();
      setFile(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Falha ao importar planilha');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      onClick={closeImport}
      className="anim-fade"
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.6)', zIndex: 90, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, backdropFilter: 'blur(3px)' }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="anim-pop"
        style={{ width: 640, maxWidth: '100%', maxHeight: '90vh', overflowY: 'auto', background: '#111318', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, boxShadow: '0 30px 80px rgba(0,0,0,.6)' }}
      >
        <div style={{ padding: '20px 24px', borderBottom: '1px solid rgba(255,255,255,.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--accent-bg)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="upload" size={18} />
            </div>
            <div>
              <h2 style={{ fontSize: 16, fontWeight: 600 }}>Importar processos do Excel</h2>
              <p style={{ marginTop: 2, fontSize: 12, color: '#8b909c' }}>Mapeamento automático das colunas da planilha</p>
            </div>
          </div>
          <button onClick={closeImport} className="btn" style={{ width: 32, height: 32, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#8b909c' }}>
            <Icon name="x" size={18} />
          </button>
        </div>
        <div style={{ padding: 24 }}>
          <div
            onClick={() => fileRef.current?.click()}
            style={{
              border: '1.5px dashed rgba(255,255,255,.15)',
              borderRadius: 12,
              padding: 30,
              textAlign: 'center',
              background: 'rgba(255,255,255,.015)',
              marginBottom: 20,
              cursor: 'pointer',
            }}
          >
            <Icon name="file" size={30} style={{ color: 'var(--accent)', marginBottom: 10 }} />
            <div style={{ fontSize: 14, fontWeight: 550 }}>{file ? file.name : 'Clique para selecionar uma planilha .xlsx'}</div>
            <div style={{ fontSize: 12, color: '#6f7480', marginTop: 3 }}>
              {file ? 'Arquivo selecionado · pronto para importar' : 'Ex.: Auditoria Processos TRIBUTÁRIO.xlsx'}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx"
              style={{ display: 'none' }}
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </div>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#8b909c', textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 11 }}>
            Mapeamento de colunas
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 22 }}>
            {COLUMN_MAP.map((c) => (
              <div key={c.col} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 13px', background: 'rgba(255,255,255,.02)', border: '1px solid rgba(255,255,255,.06)', borderRadius: 9 }}>
                <span style={{ flex: 1, fontSize: 12.5, color: '#c3c7ce', fontFamily: "'Geist Mono',monospace" }}>{c.col}</span>
                <Icon name="arrow-right" size={15} style={{ color: '#6f7480' }} />
                <span style={{ flex: 1, fontSize: 12.5, fontWeight: 550, color: 'var(--accent)' }}>{c.field}</span>
                <Icon name="check-circle" size={16} style={{ color: '#35c28a' }} />
              </div>
            ))}
          </div>
          {error && (
            <div style={{ marginBottom: 14, fontSize: 12.5, color: '#e5644e', background: 'rgba(229,100,78,.1)', border: '1px solid rgba(229,100,78,.25)', borderRadius: 8, padding: '9px 11px' }}>
              {error}
            </div>
          )}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <button onClick={closeImport} className="btn" style={{ height: 37, padding: '0 16px', borderRadius: 9, border: '1px solid rgba(255,255,255,.12)', color: '#c3c7ce', fontSize: 13, fontWeight: 500 }}>
              Cancelar
            </button>
            <button
              onClick={handleConfirm}
              disabled={busy}
              className="btn btn-accent"
              style={{ display: 'flex', alignItems: 'center', gap: 7, height: 37, padding: '0 18px', borderRadius: 9, background: 'var(--accent)', color: 'var(--accent-fg)', fontWeight: 600, fontSize: 13, opacity: busy ? 0.7 : 1 }}
            >
              {busy ? <span className="spinner" /> : <Icon name="check" size={16} sw={2.4} />}
              Importar processos
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
