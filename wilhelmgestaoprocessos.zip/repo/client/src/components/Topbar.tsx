import { useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useUI } from '../context/UIContext';
import { useProcesses } from '../context/ProcessesContext';
import { useCan } from '../context/AuthContext';
import NotificationsDropdown from './NotificationsDropdown';

function useBreadcrumb() {
  const { pathname } = useLocation();
  const params = useParams();
  const { processes } = useProcesses();

  if (pathname === '/dashboard') return { icon: 'dashboard', title: 'Dashboard', sub: '' };
  if (pathname === '/processos') return { icon: 'list', title: 'Processos', sub: 'Lista' };
  if (pathname === '/processos/kanban') return { icon: 'columns', title: 'Processos', sub: 'Kanban' };
  if (pathname === '/processos/timeline') return { icon: 'layers', title: 'Processos', sub: 'Timeline' };
  if (pathname.startsWith('/processos/') && params.id) {
    const p = processes.find((x) => x.id === params.id);
    return { icon: 'folder', title: 'Processos', sub: p ? p.cliente : '' };
  }
  if (pathname === '/equipe') return { icon: 'users', title: 'Equipe', sub: '' };
  if (pathname === '/calendario') return { icon: 'calendar', title: 'Calendário', sub: '' };
  if (pathname === '/relatorios') return { icon: 'bars', title: 'Relatórios', sub: '' };
  if (pathname === '/configuracoes') return { icon: 'settings', title: 'Configurações', sub: '' };
  return { icon: 'dashboard', title: 'Dashboard', sub: '' };
}

export default function Topbar() {
  const crumb = useBreadcrumb();
  const { openCommand, openImport, notifOpen, toggleNotif, closeNotif, openNewDrawer } = useUI();
  const canImport = useCan('IMPORT_EXPORT');
  const canEdit = useCan('EDIT_PROCESSES');

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        openCommand();
      }
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [openCommand]);

  return (
    <header
      style={{
        height: 58,
        flex: 'none',
        borderBottom: '1px solid rgba(255,255,255,.06)',
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        padding: '0 22px',
        background: 'rgba(10,11,13,.85)',
        backdropFilter: 'blur(8px)',
      }}
      onClick={() => notifOpen && closeNotif()}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#8b909c' }}>
        <Icon name={crumb.icon} size={15} style={{ color: 'var(--accent)' }} />
        <span style={{ color: 'var(--text)', fontWeight: 550 }}>{crumb.title}</span>
        {crumb.sub && (
          <>
            <Icon name="chevron-right" size={14} />
            <span>{crumb.sub}</span>
          </>
        )}
      </div>
      <div style={{ flex: 1 }} />
      <button
        onClick={(e) => {
          e.stopPropagation();
          openCommand();
        }}
        className="btn"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 9,
          height: 34,
          padding: '0 11px 0 12px',
          border: '1px solid rgba(255,255,255,.09)',
          borderRadius: 9,
          color: '#8b909c',
          fontSize: 13,
          background: 'rgba(255,255,255,.02)',
          minWidth: 230,
        }}
      >
        <Icon name="search" size={15} />
        <span style={{ flex: 1, textAlign: 'left' }}>Buscar processo, cliente, CNPJ…</span>
        <span style={{ fontFamily: "'Geist Mono',monospace", fontSize: 11, border: '1px solid rgba(255,255,255,.12)', borderRadius: 5, padding: '1px 5px', color: '#6f7480' }}>⌘K</span>
      </button>
      {canImport && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            openImport();
          }}
          title="Importar Excel"
          className="btn"
          style={{ width: 34, height: 34, borderRadius: 9, border: '1px solid rgba(255,255,255,.09)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#a4a9b4' }}
        >
          <Icon name="upload" size={16} />
        </button>
      )}
      <div style={{ position: 'relative' }}>
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleNotif();
          }}
          className="btn"
          style={{ width: 34, height: 34, borderRadius: 9, border: '1px solid rgba(255,255,255,.09)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#a4a9b4', position: 'relative' }}
        >
          <Icon name="bell" size={16} />
          <span style={{ position: 'absolute', top: 6, right: 6, width: 7, height: 7, borderRadius: '50%', background: '#e5644e', border: '1.5px solid #0a0b0d' }} />
        </button>
        {notifOpen && <div onClick={(e) => e.stopPropagation()}><NotificationsDropdown /></div>}
      </div>
      {canEdit && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            openNewDrawer();
          }}
          className="btn btn-accent"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 7,
            height: 34,
            padding: '0 14px',
            borderRadius: 9,
            background: 'var(--accent)',
            color: 'var(--accent-fg)',
            fontWeight: 600,
            fontSize: 13,
            boxShadow: '0 2px 10px rgba(214,165,42,.22)',
          }}
        >
          <Icon name="plus" size={16} sw={2.2} />
          Novo processo
        </button>
      )}
    </header>
  );
}
