import type { ReactNode } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import Login from './pages/Login';
import AppShell from './pages/AppShell';
import Dashboard from './pages/Dashboard';
import Lista from './pages/processos/Lista';
import Kanban from './pages/processos/Kanban';
import Timeline from './pages/processos/Timeline';
import ProcessDetail from './pages/ProcessDetail';
import Equipe from './pages/Equipe';
import BlankPage from './pages/BlankPage';

function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function RedirectIfAuthed({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route
              path="/login"
              element={
                <RedirectIfAuthed>
                  <Login />
                </RedirectIfAuthed>
              }
            />
            <Route
              path="/"
              element={
                <RequireAuth>
                  <AppShell />
                </RequireAuth>
              }
            >
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="processos" element={<Lista />} />
              <Route path="processos/kanban" element={<Kanban />} />
              <Route path="processos/timeline" element={<Timeline />} />
              <Route path="processos/:id" element={<ProcessDetail />} />
              <Route path="equipe" element={<Equipe />} />
              <Route path="calendario" element={<BlankPage title="Calendário" icon="calendar" />} />
              <Route path="relatorios" element={<BlankPage title="Relatórios" icon="bars" />} />
              <Route path="configuracoes" element={<BlankPage title="Configurações" icon="settings" />} />
            </Route>
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  );
}
