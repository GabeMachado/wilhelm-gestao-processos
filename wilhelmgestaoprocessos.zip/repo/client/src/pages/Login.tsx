import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Icon } from '../lib/icons';
import { ApiError } from '../lib/api';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('camila@wilhelm.adv.br');
  const [password, setPassword] = useState('senha-demo');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Não foi possível entrar');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="anim-fade" style={{ height: '100vh', display: 'flex' }}>
      <div
        style={{
          flex: 1,
          minWidth: 0,
          background:
            'radial-gradient(120% 100% at 0% 0%, rgba(214,165,42,.15), transparent 55%), linear-gradient(160deg,#0c0d11,#0a0b0d)',
          borderRight: '1px solid rgba(255,255,255,.06)',
          padding: '52px 58px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              background: 'linear-gradient(150deg,var(--accent),#a97c14)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#1a1400',
              boxShadow: '0 4px 22px rgba(214,165,42,.3)',
            }}
          >
            <Icon name="scale" size={24} sw={2} />
          </div>
          <div>
            <div style={{ fontSize: 19, fontWeight: 600, letterSpacing: '.2px' }}>Wilhelm</div>
            <div style={{ fontSize: 11, color: '#6f7480', letterSpacing: '.6px', textTransform: 'uppercase' }}>
              Advogados · Tributário
            </div>
          </div>
        </div>
        <div style={{ maxWidth: 460 }}>
          <h1 style={{ fontSize: 34, fontWeight: 600, letterSpacing: '-.6px', lineHeight: 1.2, margin: '0 0 16px' }}>
            Gestão inteligente de
            <br />
            processos tributários
          </h1>
          <p style={{ fontSize: 15, color: '#a4a9b4', lineHeight: 1.6, margin: '0 0 32px' }}>
            Acompanhe cada tese em recuperação de crédito — do recebimento de documentos à compensação e
            honorários — com rastreabilidade total.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 15 }}>
            <Feature icon="check-circle" color="#35c28a" bg="rgba(53,194,138,.14)" text="Fluxo automatizado por etapas do processo" />
            <Feature icon="layers" color="#5b8def" bg="rgba(91,141,239,.14)" text="Kanban, Timeline e dashboards em tempo real" />
            <Feature icon="users" color="var(--accent)" bg="var(--accent-bg)" text="Auditoria e permissões por perfil de usuário" />
          </div>
        </div>
        <div style={{ fontSize: 12, color: '#4b505a' }}>© 2026 Wilhelm Advogados · Todos os direitos reservados</div>
      </div>
      <div style={{ width: 480, flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40, background: '#0a0b0d' }}>
        <form onSubmit={handleSubmit} className="anim-slideup" style={{ width: '100%', maxWidth: 344 }}>
          <h2 style={{ fontSize: 23, fontWeight: 600, margin: '0 0 6px', letterSpacing: '-.3px' }}>Entrar na plataforma</h2>
          <p style={{ fontSize: 13, color: '#8b909c', margin: '0 0 28px' }}>Use suas credenciais do escritório para acessar.</p>

          <label style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 15 }}>
            <span style={{ fontSize: 12.5, color: '#a4a9b4', fontWeight: 500 }}>E-mail</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="text-input"
              style={{ height: 42, padding: '0 13px', fontSize: 14 }}
            />
          </label>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 14 }}>
            <span style={{ fontSize: 12.5, color: '#a4a9b4', fontWeight: 500 }}>Senha</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="text-input"
              style={{ height: 42, padding: '0 13px', fontSize: 14 }}
            />
          </label>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', fontSize: 12.5, color: '#a4a9b4' }}>
              <input type="checkbox" defaultChecked style={{ accentColor: 'var(--accent)', width: 15, height: 15 }} />
              Manter conectado
            </label>
            <span style={{ fontSize: 12.5, color: 'var(--accent)', cursor: 'pointer' }}>Esqueceu a senha?</span>
          </div>

          {error && (
            <div style={{ marginBottom: 14, fontSize: 12.5, color: '#e5644e', background: 'rgba(229,100,78,.1)', border: '1px solid rgba(229,100,78,.25)', borderRadius: 8, padding: '9px 11px' }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="btn btn-accent"
            style={{
              width: '100%',
              height: 44,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              borderRadius: 11,
              background: 'var(--accent)',
              color: 'var(--accent-fg)',
              fontWeight: 600,
              fontSize: 14,
              boxShadow: '0 4px 16px rgba(214,165,42,.24)',
              opacity: busy ? 0.75 : 1,
            }}
          >
            {busy ? 'Entrando…' : 'Entrar'}
            <Icon name="arrow-right" size={17} sw={2.2} />
          </button>
          <button
            type="button"
            className="btn"
            style={{
              width: '100%',
              height: 44,
              marginTop: 11,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              borderRadius: 11,
              border: '1px solid rgba(255,255,255,.12)',
              color: '#c3c7ce',
              fontWeight: 500,
              fontSize: 13.5,
            }}
          >
            <Icon name="briefcase" size={16} />
            Entrar com SSO do escritório
          </button>
          <p style={{ margin: '24px 0 0', fontSize: 11.5, color: '#4b505a', textAlign: 'center', lineHeight: 1.6 }}>
            Ambiente de demonstração — use qualquer e-mail semeado (ex.: camila@wilhelm.adv.br) com a senha{' '}
            <b style={{ color: '#8b909c' }}>senha-demo</b>.
          </p>
        </form>
      </div>
    </div>
  );
}

function Feature({ icon, color, bg, text }: { icon: string; color: string; bg: string; text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{ width: 32, height: 32, flex: 'none', borderRadius: 9, background: bg, color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={17} />
      </div>
      <span style={{ fontSize: 13.5, color: '#c3c7ce' }}>{text}</span>
    </div>
  );
}
