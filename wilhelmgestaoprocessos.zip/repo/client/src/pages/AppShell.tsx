import { Outlet } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import Drawer from '../components/Drawer';
import ImportModal from '../components/ImportModal';
import ConfirmDialog from '../components/ConfirmDialog';
import CommandPalette from '../components/CommandPalette';
import { ProcessesProvider } from '../context/ProcessesContext';
import { UIProvider } from '../context/UIContext';

export default function AppShell() {
  return (
    <ProcessesProvider>
      <UIProvider>
        <div style={{ display: 'grid', gridTemplateColumns: '250px 1fr', height: '100vh', width: '100%', overflow: 'hidden' }}>
          <Sidebar />
          <main style={{ display: 'flex', flexDirection: 'column', minWidth: 0, minHeight: 0, background: '#0a0b0d' }}>
            <Topbar />
            <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>
              <Outlet />
            </div>
          </main>
        </div>
        <Drawer />
        <ImportModal />
        <ConfirmDialog />
        <CommandPalette />
      </UIProvider>
    </ProcessesProvider>
  );
}
