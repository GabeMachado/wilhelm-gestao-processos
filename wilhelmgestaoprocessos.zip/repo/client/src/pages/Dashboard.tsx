import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { api } from '../lib/api';
import { useProcesses } from '../context/ProcessesContext';
import { moneyShort } from '../lib/format';
import type { DashboardData } from '../lib/types';

function fmtDate(d: string) {
  const date = new Date(d);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(date.getDate())}/${p(date.getMonth() + 1)}/${date.getFullYear()}`;
}

const ICON_BY_KIND: Record<string, string> = { CREATE: 'plus', DONE: 'check', CURRENT: 'clock', EDIT: 'pencil', MOVE: 'columns', DELETE: 'trash' };
const COLOR_BY_KIND: Record<string, { c: string; b: string }> = {
  CREATE: { c: '#5b8def', b: 'rgba(91,141,239,.14)' },
  DONE: { c: '#35c28a', b: 'rgba(53,194,138,.14)' },
  CURRENT: { c: '#e0a53a', b: 'rgba(224,165,58,.14)' },
  EDIT: { c: '#8b7bd8', b: 'rgba(139,123,216,.14)' },
  MOVE: { c: '#3bc0c8', b: 'rgba(59,192,200,.14)' },
  DELETE: { c: '#e5644e', b: 'rgba(229,100,78,.14)' },
};

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const { setFilters } = useProcesses();
  const navigate = useNavigate();

  useEffect(() => {
    api.get<DashboardData>('/dashboard').then(setData);
  }, []);

  async function handleExport() {
    const blob = await api.get<Blob>('/export');
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'processos-wilhelm.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  function goToPendencia(key: string) {
    if (!key) {
      navigate('/processos');
      return;
    }
    setFilters({ etapa: key as never, status: '' });
    navigate('/processos');
  }

  if (!data) return null;

  return (
    <div className="anim-fade" style={{ padding: '26px 28px 44px', maxWidth: 1320 }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 22, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 23, fontWeight: 600, letterSpacing: '-.3px' }}>Visão geral da carteira</h1>
          <p style={{ marginTop: 5, color: '#8b909c', fontSize: 13.5 }}>Acompanhe o andamento das teses tributárias em recuperação de crédito.</p>
        </div>
        <button
          onClick={handleExport}
          className="btn"
          style={{ display: 'flex', alignItems: 'center', gap: 7, height: 34, padding: '0 13px', borderRadius: 9, border: '1px solid rgba(255,255,255,.1)', color: '#c3c7ce', fontSize: 12.5, fontWeight: 500 }}
        >
          <Icon name="download" size={15} />
          Exportar
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 14 }}>
        {data.metrics.map((m) => (
          <div key={m.label} style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '16px 17px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: m.bg, color: m.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={m.icon} size={18} />
              </div>
            </div>
            <div style={{ fontSize: 27, fontWeight: 600, letterSpacing: '-.5px', marginTop: 14, fontVariantNumeric: 'tabular-nums' }}>
              {m.isMoney ? moneyShort(m.value) : m.value}
            </div>
            <div style={{ fontSize: 12.5, color: '#8b909c', marginTop: 2 }}>{m.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 12, marginBottom: 22 }}>
        {data.pendencias.map((p) => (
          <div
            key={p.label}
            onClick={() => goToPendencia(p.key)}
            className="card-hover"
            style={{ background: '#0e0f13', border: '1px solid rgba(255,255,255,.06)', borderRadius: 12, padding: '13px 14px', cursor: 'pointer' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: p.color }}>
              <Icon name={p.icon} size={15} />
              <span style={{ fontSize: 22, fontWeight: 600, color: 'var(--text)', fontVariantNumeric: 'tabular-nums' }}>{p.count}</span>
            </div>
            <div style={{ fontSize: 11.5, color: '#8b909c', marginTop: 5, lineHeight: 1.3 }}>{p.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.15fr 1fr', gap: 14, marginBottom: 14 }}>
        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, fontWeight: 600 }}>Funil por etapa do fluxo</h3>
            <span style={{ fontSize: 11.5, color: '#6f7480' }}>processos ativos + encerrados</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {data.barEtapa.map((b) => (
              <div key={b.label} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 120, flex: 'none', fontSize: 12, color: '#a4a9b4', textAlign: 'right', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{b.label}</div>
                <div style={{ flex: 1, height: 26, background: 'rgba(255,255,255,.03)', borderRadius: 7, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${b.pct}%`, background: b.color, borderRadius: 7, transition: 'width .5s ease' }} />
                </div>
                <div style={{ width: 34, flex: 'none', textAlign: 'right', fontSize: 13, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{b.count}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '18px 20px' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Resultado dos julgados</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: 22, marginTop: 12 }}>
            <div
              style={{
                width: 132,
                height: 132,
                borderRadius: '50%',
                flex: 'none',
                background: `conic-gradient(${donutGradient(data.resultadoLegend)})`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <div style={{ width: 88, height: 88, borderRadius: '50%', background: '#101116', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ fontSize: 22, fontWeight: 600, color: 'var(--accent)' }}>{data.exitoPct}%</div>
                <div style={{ fontSize: 10, color: '#6f7480' }}>êxito</div>
              </div>
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 9 }}>
              {data.resultadoLegend.map((r) => (
                <div key={r.label} style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                  <span style={{ width: 9, height: 9, borderRadius: 3, background: r.color, flex: 'none' }} />
                  <span style={{ flex: 1, fontSize: 12.5, color: '#c3c7ce' }}>{r.label}</span>
                  <span style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{r.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <h3 style={{ fontSize: 14, fontWeight: 600 }}>Movimentação por mês</h3>
            <div style={{ display: 'flex', gap: 14, fontSize: 11, color: '#8b909c' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--accent)' }} />
                entradas
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: '#35c28a' }} />
                encerrados
              </span>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 150, paddingTop: 14 }}>
            {data.barMes.map((b) => (
              <div key={b.label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, height: '100%', justifyContent: 'flex-end' }}>
                <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', width: '100%', justifyContent: 'center', height: '100%' }}>
                  <div title={String(b.entradas)} style={{ width: '44%', height: `${b.hEnt}%`, background: 'linear-gradient(180deg,var(--accent),#a97c14)', borderRadius: '4px 4px 0 0' }} />
                  <div title={String(b.encerrados)} style={{ width: '44%', height: `${b.hEnc}%`, background: 'linear-gradient(180deg,#35c28a,#1c7d57)', borderRadius: '4px 4px 0 0' }} />
                </div>
                <div style={{ fontSize: 10.5, color: '#6f7480' }}>{b.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '18px 20px' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>Carga por responsável</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {data.barResp.map((b) => (
              <div key={b.name} style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <div style={{ width: 27, height: 27, flex: 'none', borderRadius: 7, background: b.bg, color: b.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600 }}>
                  {b.initials}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, color: '#c3c7ce', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{b.name}</span>
                    <span style={{ fontSize: 12, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{b.count}</span>
                  </div>
                  <div style={{ height: 6, background: 'rgba(255,255,255,.04)', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${b.pct}%`, background: b.color, borderRadius: 4 }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '18px 20px' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icon name="calendar-clock" size={16} style={{ color: '#e5644e' }} />
            Prazos & próximas ações
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {data.prazos.map((p) => {
              const over = p.dias < 0;
              const color = over ? '#e5644e' : p.dias <= 7 ? '#e0a53a' : '#8b909c';
              const bg = over ? 'rgba(229,100,78,.13)' : p.dias <= 7 ? 'rgba(224,165,58,.13)' : 'rgba(139,144,156,.1)';
              return (
                <div
                  key={p.pid}
                  onClick={() => navigate(`/processos/${p.pid}`)}
                  className="row-hover"
                  style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderTop: '1px solid rgba(255,255,255,.04)', cursor: 'pointer' }}
                >
                  <div style={{ width: 44, flex: 'none', textAlign: 'center' }}>
                    <div style={{ fontSize: 15, fontWeight: 600, color, fontVariantNumeric: 'tabular-nums' }}>{Math.abs(p.dias)}</div>
                    <div style={{ fontSize: 9, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.4px' }}>{over ? 'atraso' : 'dias'}</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.cliente}</div>
                    <div style={{ fontSize: 11.5, color: '#8b909c', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.acao}</div>
                  </div>
                  <span style={{ fontSize: 10.5, fontWeight: 600, color, background: bg, padding: '3px 8px', borderRadius: 6, whiteSpace: 'nowrap' }}>{fmtDate(p.prazo)}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, padding: '18px 20px' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icon name="activity" size={16} style={{ color: 'var(--accent)' }} />
            Atividade recente
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {data.recentAtiv.map((a, i) => {
              const ck = COLOR_BY_KIND[a.kind] || COLOR_BY_KIND.DONE;
              return (
                <div key={i} style={{ display: 'flex', gap: 12, padding: '9px 0' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div style={{ width: 26, height: 26, flex: 'none', borderRadius: 7, background: ck.b, color: ck.c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icon name={ICON_BY_KIND[a.kind] || 'check'} size={13} />
                    </div>
                    <div style={{ width: 1, flex: 1, background: 'rgba(255,255,255,.06)', marginTop: 3 }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0, paddingBottom: 6 }}>
                    <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>
                      <span style={{ fontWeight: 550 }}>{a.user}</span> {a.text.replace('Processo ', '').toLowerCase()}
                    </div>
                    <div style={{ fontSize: 11, color: '#6f7480', marginTop: 2 }}>
                      {a.cliente} · {fmtDate(a.when)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function donutGradient(legend: { label: string; count: number; color: string }[]): string {
  const total = legend.reduce((a, l) => a + l.count, 0) || 1;
  let acc = 0;
  const segs: string[] = [];
  legend.forEach((l) => {
    const frac = l.count / total;
    if (frac > 0) {
      segs.push(`${l.color} ${(acc * 360).toFixed(1)}deg ${((acc + frac) * 360).toFixed(1)}deg`);
      acc += frac;
    }
  });
  return segs.join(',');
}
