import { useEffect, useState } from 'react';
import { Icon } from '../lib/icons';
import { api } from '../lib/api';
import { useCan } from '../context/AuthContext';
import type { PermissionsData, TeamData } from '../lib/types';

export default function Equipe() {
  const [team, setTeam] = useState<TeamData | null>(null);
  const [perms, setPerms] = useState<PermissionsData | null>(null);
  const canManageTeam = useCan('MANAGE_TEAM');

  useEffect(() => {
    api.get<TeamData>('/users').then(setTeam);
    api.get<PermissionsData>('/users/permissions').then(setPerms);
  }, []);

  if (!team || !perms) return null;

  return (
    <div className="anim-fade" style={{ padding: '26px 28px 50px', maxWidth: 1120 }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 22, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 23, fontWeight: 600, letterSpacing: '-.3px' }}>Equipe & Permissões</h1>
          <p style={{ marginTop: 5, color: '#8b909c', fontSize: 13.5 }}>Gerencie os membros do escritório e o que cada perfil pode fazer no sistema.</p>
        </div>
        {canManageTeam && (
          <button className="btn btn-accent" style={{ display: 'flex', alignItems: 'center', gap: 7, height: 34, padding: '0 14px', borderRadius: 9, background: 'var(--accent)', color: 'var(--accent-fg)', fontWeight: 600, fontSize: 13 }}>
            <Icon name="plus" size={16} sw={2.2} />
            Convidar membro
          </button>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 13, marginBottom: 26 }}>
        {team.roles.map((r) => (
          <div key={r.key} style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, padding: '16px 17px', borderTop: `2px solid ${r.color}` }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13.5, fontWeight: 600, color: r.color }}>{r.label}</span>
              <span style={{ fontSize: 20, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{r.count}</span>
            </div>
            <div style={{ fontSize: 12, color: '#8b909c', marginTop: 6, lineHeight: 1.4 }}>{r.desc}</div>
          </div>
        ))}
      </div>

      <div style={{ fontSize: 11, fontWeight: 600, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 12 }}>Membros · {team.teamCount}</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 12, marginBottom: 28 }}>
        {team.team.map((m) => (
          <div key={m.id} style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, padding: '15px 17px', display: 'flex', alignItems: 'center', gap: 13 }}>
            <div style={{ position: 'relative', flex: 'none' }}>
              <div style={{ width: 42, height: 42, borderRadius: 11, background: m.bg, color: m.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 600 }}>{m.initials}</div>
              <span style={{ position: 'absolute', bottom: -1, right: -1, width: 12, height: 12, borderRadius: '50%', background: m.online ? '#35c28a' : '#4b505a', border: '2.5px solid #101116' }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.nome}</div>
              <div style={{ fontSize: 11.5, color: '#6f7480', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.email}</div>
              <div style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 10.5, fontWeight: 600, color: m.roleColor, background: m.roleBg, padding: '2px 8px', borderRadius: 6 }}>{m.roleLabel}</span>
                <span style={{ fontSize: 11, color: '#8b909c' }}>{m.count} processos</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 14, overflow: 'hidden' }}>
        <div style={{ padding: '15px 20px', borderBottom: '1px solid rgba(255,255,255,.06)', display: 'flex', alignItems: 'center', gap: 9 }}>
          <Icon name="scale" size={16} style={{ color: 'var(--accent)' }} />
          <span style={{ fontSize: 14, fontWeight: 600 }}>Matriz de permissões</span>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed', minWidth: 600 }}>
            <thead>
              <tr style={{ background: '#0e0f13' }}>
                <th style={{ textAlign: 'left', padding: '12px 20px', fontSize: 11, fontWeight: 600, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.4px', width: '38%' }}>Permissão</th>
                {perms.roles.map((r) => (
                  <th key={r.key} style={{ padding: '12px 8px', fontSize: 11, fontWeight: 600, color: r.color, textTransform: 'uppercase', letterSpacing: '.3px', textAlign: 'center' }}>
                    {r.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {perms.rows.map((row) => (
                <tr key={row.key} style={{ borderTop: '1px solid rgba(255,255,255,.05)' }}>
                  <td style={{ padding: '13px 20px', fontSize: 12.5, color: '#c3c7ce' }}>{row.label}</td>
                  {perms.roles.map((r) => (
                    <td key={r.key} style={{ padding: '13px 8px', textAlign: 'center' }}>
                      {row.roles.includes(r.key) ? (
                        <span style={{ display: 'inline-flex', color: r.color }}>
                          <Icon name="check-circle" size={18} />
                        </span>
                      ) : (
                        <span style={{ color: '#3a3f48', fontSize: 14 }}>—</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
