import { useNavigate } from 'react-router-dom';
import { Icon } from '../../lib/icons';
import ProcessosHeader from '../../components/ProcessosHeader';
import { useProcesses } from '../../context/ProcessesContext';
import { ETAPAS, etapaIndex } from '../../lib/format';
import type { Processo } from '../../lib/types';

function stepFor(p: Processo, idx: number) {
  const em = ETAPAS[idx];
  const ei = etapaIndex(p.etapa);
  const isEncerrado = p.etapa === 'ENCERRADO';
  if (idx < ei || (isEncerrado && idx <= 5)) {
    return { icon: 'check', track: em.color, dotBg: em.color, dotBorder: em.color, iconColor: '#0a0b0d' };
  }
  if (idx === ei && !isEncerrado) {
    return { icon: em.icon, track: 'rgba(255,255,255,.06)', dotBg: '#101116', dotBorder: em.color, iconColor: em.color };
  }
  return { icon: 'circle', track: 'rgba(255,255,255,.05)', dotBg: '#101116', dotBorder: 'rgba(255,255,255,.12)', iconColor: '#3a3f48' };
}

export default function Timeline() {
  const { filtered } = useProcesses();
  const navigate = useNavigate();

  return (
    <div className="anim-fade" style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      <ProcessosHeader active="timeline" />
      <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '4px 28px 40px' }}>
        <div style={{ border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, overflow: 'hidden', background: '#0e0f13' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '230px repeat(6,1fr)', borderBottom: '1px solid rgba(255,255,255,.06)', background: '#101116' }}>
            <div style={{ padding: '11px 16px', fontSize: 11, fontWeight: 600, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.5px' }}>Processo</div>
            {ETAPAS.map((e) => (
              <div key={e.key} style={{ padding: '11px 8px', fontSize: 10.5, fontWeight: 600, color: e.color, textTransform: 'uppercase', letterSpacing: '.3px', textAlign: 'center', borderLeft: '1px solid rgba(255,255,255,.04)' }}>
                {e.short}
              </div>
            ))}
          </div>
          {filtered.map((p) => (
            <div
              key={p.id}
              onClick={() => navigate(`/processos/${p.id}`)}
              className="row-hover"
              style={{ display: 'grid', gridTemplateColumns: '230px repeat(6,1fr)', borderTop: '1px solid rgba(255,255,255,.05)', cursor: 'pointer' }}
            >
              <div style={{ padding: '12px 16px', minWidth: 0 }}>
                <div style={{ fontSize: 12.5, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.cliente}</div>
                <div style={{ fontFamily: "'Geist Mono',monospace", fontSize: 10.5, color: '#6f7480' }}>{p.pasta}</div>
              </div>
              {ETAPAS.map((e, idx) => {
                const s = stepFor(p, idx);
                return (
                  <div key={e.key} style={{ borderLeft: '1px solid rgba(255,255,255,.04)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', padding: '12px 4px' }}>
                    <div style={{ width: '100%', height: 5, borderRadius: 3, background: s.track, position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)' }} />
                    <span
                      style={{
                        position: 'relative',
                        width: 20,
                        height: 20,
                        borderRadius: '50%',
                        background: s.dotBg,
                        border: `2px solid ${s.dotBorder}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: s.iconColor,
                      }}
                    >
                      <Icon name={s.icon} size={11} sw={2.4} />
                    </span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
