import { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '../../lib/icons';
import ProcessosHeader from '../../components/ProcessosHeader';
import { useProcesses } from '../../context/ProcessesContext';
import { useToast } from '../../context/ToastContext';
import { useCan } from '../../context/AuthContext';
import { api, ApiError } from '../../lib/api';
import { diasView, emeta, tipoMeta, ETAPAS } from '../../lib/format';
import type { Etapa, Processo } from '../../lib/types';

export default function Kanban() {
  const { filtered, upsertLocal } = useProcesses();
  const flash = useToast();
  const navigate = useNavigate();
  const canAdvance = useCan('ADVANCE_FLOW');
  const dragId = useRef<string | null>(null);

  const columns = ETAPAS.map((e) => ({
    ...e,
    cards: filtered.filter((p) => p.etapa === e.key),
  }));

  async function handleDrop(etapa: Etapa) {
    const id = dragId.current;
    dragId.current = null;
    if (!id) return;
    const current = filtered.find((p) => p.id === id);
    if (!current || current.etapa === etapa) return;
    try {
      const updated = await api.post<Processo>(`/processos/${id}/move`, { etapa });
      upsertLocal(updated);
      flash(`Processo movido para ${emeta(etapa).label}`);
    } catch (err) {
      flash(err instanceof ApiError ? err.message : 'Não foi possível mover o processo', 'warn');
    }
  }

  return (
    <div className="anim-fade" style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      <ProcessosHeader active="kanban" />
      <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '4px 28px 30px' }}>
        <div style={{ display: 'flex', gap: 14, minWidth: 'min-content', height: '100%' }}>
          {columns.map((col) => (
            <div
              key={col.key}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => handleDrop(col.key)}
              style={{ width: 276, flex: 'none', display: 'flex', flexDirection: 'column', minHeight: 0, background: '#0c0d11', border: '1px solid rgba(255,255,255,.05)', borderRadius: 13, overflow: 'hidden' }}
            >
              <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 9, borderBottom: '1px solid rgba(255,255,255,.05)', borderTop: `2px solid ${col.color}` }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: col.color }} />
                <span style={{ fontSize: 12.5, fontWeight: 600, flex: 1 }}>{col.label}</span>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#8b909c', background: 'rgba(255,255,255,.05)', padding: '1px 8px', borderRadius: 20 }}>{col.cards.length}</span>
              </div>
              <div style={{ flex: 1, overflowY: 'auto', padding: 10, display: 'flex', flexDirection: 'column', gap: 9, minHeight: 80 }}>
                {col.cards.map((p) => {
                  const tm = tipoMeta(p.tipo);
                  const dv = diasView(p.etapa, p.prazo);
                  const advShort = p.adv.replace('Dra. ', '').replace('Dr. ', '');
                  const initials = advShort.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
                  return (
                    <div
                      key={p.id}
                      draggable={canAdvance}
                      onDragStart={(e) => {
                        dragId.current = p.id;
                        e.dataTransfer.effectAllowed = 'move';
                        e.currentTarget.style.opacity = '.4';
                      }}
                      onDragEnd={(e) => {
                        e.currentTarget.style.opacity = '1';
                      }}
                      onClick={() => navigate(`/processos/${p.id}`)}
                      className="card-hover"
                      style={{ background: '#14161c', border: '1px solid rgba(255,255,255,.07)', borderRadius: 10, padding: '11px 12px', cursor: 'pointer', boxShadow: '0 1px 3px rgba(0,0,0,.3)' }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 7 }}>
                        <span style={{ fontFamily: "'Geist Mono',monospace", fontSize: 10.5, color: '#6f7480' }}>{p.pasta}</span>
                        <span style={{ fontSize: 9.5, fontWeight: 600, color: tm.color, background: tm.bg, padding: '1px 6px', borderRadius: 5 }}>{tm.s}</span>
                      </div>
                      <div style={{ fontSize: 12.5, fontWeight: 550, lineHeight: 1.3, marginBottom: 4 }}>{p.cliente}</div>
                      <div
                        style={{
                          fontSize: 11,
                          color: '#8b909c',
                          lineHeight: 1.35,
                          marginBottom: 10,
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}
                      >
                        {p.tese}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <span style={{ width: 22, height: 22, borderRadius: 6, background: tm.bg, color: tm.color, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600 }}>
                          {initials}
                        </span>
                        <span style={{ fontSize: 10.5, fontWeight: 600, color: dv.color, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <Icon name="clock" size={12} />
                          {dv.txt}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
