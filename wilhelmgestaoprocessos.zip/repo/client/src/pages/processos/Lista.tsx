import { useNavigate } from 'react-router-dom';
import { Icon } from '../../lib/icons';
import ProcessosHeader from '../../components/ProcessosHeader';
import { useProcesses } from '../../context/ProcessesContext';
import { diasView, emeta, money, tipoMeta } from '../../lib/format';

export default function Lista() {
  const { filtered } = useProcesses();
  const navigate = useNavigate();

  return (
    <div className="anim-fade" style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      <ProcessosHeader active="lista" />
      <div style={{ flex: 1, overflow: 'auto', minHeight: 0, padding: '0 28px 40px' }}>
        <div style={{ border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, overflow: 'hidden', background: '#0e0f13' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: '#101116' }}>
                {['Processo', 'Cliente / Tese', 'Etapa', 'Status', 'Responsável', 'Próxima ação'].map((h) => (
                  <th key={h} style={{ textAlign: 'left', padding: '11px 14px', fontSize: 11, fontWeight: 600, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.5px', whiteSpace: 'nowrap' }}>
                    {h}
                  </th>
                ))}
                <th style={{ textAlign: 'right', padding: '11px 14px', fontSize: 11, fontWeight: 600, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.5px', whiteSpace: 'nowrap' }}>Prazo</th>
                <th style={{ textAlign: 'right', padding: '11px 14px', fontSize: 11, fontWeight: 600, color: '#6f7480', textTransform: 'uppercase', letterSpacing: '.5px', whiteSpace: 'nowrap' }}>Valor da causa</th>
                <th style={{ width: 36 }} />
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const em = emeta(p.etapa);
                const tm = tipoMeta(p.tipo);
                const dv = diasView(p.etapa, p.prazo);
                const advShort = p.adv.replace('Dra. ', '').replace('Dr. ', '');
                const initials = advShort
                  .split(' ')
                  .map((w) => w[0])
                  .slice(0, 2)
                  .join('')
                  .toUpperCase();
                return (
                  <tr key={p.id} onClick={() => navigate(`/processos/${p.id}`)} className="row-hover" style={{ borderTop: '1px solid rgba(255,255,255,.05)', cursor: 'pointer' }}>
                    <td style={{ padding: 'var(--rowpad) 14px', whiteSpace: 'nowrap' }}>
                      <div style={{ fontFamily: "'Geist Mono',monospace", fontSize: 12, color: '#c3c7ce' }}>{p.pasta}</div>
                      <div style={{ fontSize: 10.5, color: '#6f7480', fontFamily: "'Geist Mono',monospace" }}>{p.numero}</div>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px', maxWidth: 280 }}>
                      <div style={{ fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.cliente}</div>
                      <div style={{ fontSize: 11.5, color: '#8b909c', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.tese}</div>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, fontWeight: 500, color: em.color, background: em.bg, padding: '4px 9px', borderRadius: 7, whiteSpace: 'nowrap' }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: em.color }} />
                        {em.label}
                      </span>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px' }}>
                      <span style={{ fontSize: 11.5, fontWeight: 500, color: p.status === 'ATIVO' ? '#35c28a' : '#8b909c' }}>{p.status === 'ATIVO' ? 'Ativo' : 'Arquivado'}</span>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px', whiteSpace: 'nowrap' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
                        <span style={{ width: 22, height: 22, borderRadius: 6, background: tm.bg, color: tm.color, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600 }}>
                          {initials}
                        </span>
                        <span style={{ fontSize: 12, color: '#c3c7ce' }}>{advShort}</span>
                      </span>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px', maxWidth: 200 }}>
                      <span style={{ fontSize: 12, color: '#a4a9b4', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', display: 'block' }}>{p.proximaAcao}</span>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px', textAlign: 'right', whiteSpace: 'nowrap' }}>
                      <span style={{ fontSize: 11.5, fontWeight: 600, color: dv.color }}>{dv.txt}</span>
                    </td>
                    <td style={{ padding: 'var(--rowpad) 14px', textAlign: 'right', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums', fontSize: 12.5, color: '#c3c7ce' }}>{money(p.valorCausa)}</td>
                    <td style={{ padding: 'var(--rowpad) 6px', textAlign: 'center' }}>
                      <Icon name="chevron-right" size={15} style={{ color: '#4b505a' }} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ padding: 50, textAlign: 'center', color: '#6f7480' }}>
              <Icon name="inbox" size={30} style={{ color: '#3a3f48', marginBottom: 8 }} />
              <div style={{ fontSize: 13 }}>Nenhum processo encontrado com os filtros atuais.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
