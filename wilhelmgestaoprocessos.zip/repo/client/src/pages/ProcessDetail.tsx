import { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Icon } from '../lib/icons';
import { useUI } from '../context/UIContext';
import { useProcesses } from '../context/ProcessesContext';
import { useToast } from '../context/ToastContext';
import { useCan } from '../context/AuthContext';
import { api, ApiError } from '../lib/api';
import { ETAPAS, emeta, etapaIndex, fmtDate, money } from '../lib/format';
import type { MovimentacaoKind, Processo, ProcessoDetail as ProcessoDetailType } from '../lib/types';

const TABS = [
  { key: 'dados', label: 'Dados Gerais', icon: 'file' },
  { key: 'fluxo', label: 'Fluxo', icon: 'activity' },
  { key: 'hist', label: 'Histórico', icon: 'history' },
  { key: 'obs', label: 'Observações', icon: 'message' },
] as const;
type TabKey = (typeof TABS)[number]['key'];

const ICON_BY_KIND: Record<MovimentacaoKind, string> = { CREATE: 'plus', DONE: 'check', CURRENT: 'clock', EDIT: 'pencil', MOVE: 'columns', DELETE: 'trash' };
const COLOR_BY_KIND: Record<MovimentacaoKind, { c: string; b: string }> = {
  CREATE: { c: '#5b8def', b: 'rgba(91,141,239,.14)' },
  DONE: { c: '#35c28a', b: 'rgba(53,194,138,.14)' },
  CURRENT: { c: '#e0a53a', b: 'rgba(224,165,58,.14)' },
  EDIT: { c: '#8b7bd8', b: 'rgba(139,123,216,.14)' },
  MOVE: { c: '#3bc0c8', b: 'rgba(59,192,200,.14)' },
  DELETE: { c: '#e5644e', b: 'rgba(229,100,78,.14)' },
};
const FLUXO_DESC: Record<string, string> = {
  ENTRADA: 'Cadastro do processo e distribuição.',
  DOCUMENTOS: 'Recebimento e conferência de documentos e procuração.',
  HABILITACAO: 'Cálculo de liquidação e habilitação do crédito.',
  COMPENSACAO: 'Transmissão de PER/DCOMP e compensação tributária.',
  HONORARIOS: 'Cobrança e recebimento de honorários contratuais.',
  ENCERRADO: 'Arquivamento do processo com êxito.',
};

export default function ProcessDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { upsertLocal } = useProcesses();
  const { openEditDrawer, askDelete, drawer } = useUI();
  const flash = useToast();
  const canEdit = useCan('EDIT_PROCESSES');
  const canDelete = useCan('DELETE_PROCESSES');
  const canAdvanceFlow = useCan('ADVANCE_FLOW');

  const [detail, setDetail] = useState<ProcessoDetailType | null>(null);
  const [tab, setTab] = useState<TabKey>('dados');
  const [advancing, setAdvancing] = useState(false);

  const load = useCallback(() => {
    if (!id) return;
    api.get<ProcessoDetailType>(`/processos/${id}`).then(setDetail).catch(() => setDetail(null));
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  // refetch after the edit drawer for this process closes
  useEffect(() => {
    if (drawer === null) load();
  }, [drawer, load]);

  if (!detail) return null;
  const p = detail;
  const ei = etapaIndex(p.etapa);
  const em = emeta(p.etapa);

  async function handleAdvance() {
    setAdvancing(true);
    try {
      const updated = await api.post<Processo>(`/processos/${p.id}/advance`);
      upsertLocal(updated);
      flash('Etapa concluída · fluxo avançado');
      load();
    } catch (err) {
      flash(err instanceof ApiError ? err.message : 'Não foi possível avançar', 'warn');
    } finally {
      setAdvancing(false);
    }
  }

  return (
    <div className="anim-fade" style={{ maxWidth: 1180, margin: '0 auto', padding: '20px 28px 50px' }}>
      <button onClick={() => navigate('/processos')} className="btn" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: '#8b909c', fontSize: 12.5, marginBottom: 16 }}>
        <Icon name="arrow-left" size={15} />
        Voltar aos processos
      </button>

      <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.07)', borderRadius: 15, padding: '22px 24px', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 18, flexWrap: 'wrap' }}>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, flexWrap: 'wrap' }}>
              <span style={{ fontFamily: "'Geist Mono',monospace", fontSize: 12, color: 'var(--accent)', background: 'var(--accent-bg)', padding: '3px 9px', borderRadius: 6 }}>{p.pasta}</span>
              <span style={{ fontSize: 11.5, fontWeight: 600, color: em.color, background: em.bg, padding: '3px 9px', borderRadius: 6 }}>{p.tipo}</span>
              <span style={{ fontSize: 11.5, fontWeight: 500, color: p.status === 'ATIVO' ? '#35c28a' : '#8b909c', display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: p.status === 'ATIVO' ? '#35c28a' : '#8b909c' }} />
                {p.status === 'ATIVO' ? 'Ativo' : 'Arquivado'}
              </span>
            </div>
            <h1 style={{ margin: '0 0 5px', fontSize: 22, fontWeight: 600, letterSpacing: '-.3px' }}>{p.cliente}</h1>
            <div style={{ fontSize: 13, color: '#a4a9b4', lineHeight: 1.5 }}>{p.tese}</div>
            <div style={{ fontFamily: "'Geist Mono',monospace", fontSize: 11.5, color: '#6f7480', marginTop: 6 }}>
              {p.numero} · {p.contrario}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, flex: 'none' }}>
            {canEdit && (
              <button onClick={() => openEditDrawer(p)} className="btn" style={{ display: 'flex', alignItems: 'center', gap: 6, height: 34, padding: '0 13px', borderRadius: 9, border: '1px solid rgba(255,255,255,.12)', color: '#c3c7ce', fontSize: 12.5, fontWeight: 500 }}>
                <Icon name="pencil" size={14} />
                Editar
              </button>
            )}
            {canDelete && (
              <button onClick={() => askDelete(p.id)} className="btn" style={{ width: 34, height: 34, borderRadius: 9, border: '1px solid rgba(229,100,78,.25)', color: '#e5644e', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="trash" size={15} />
              </button>
            )}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', marginTop: 22, padding: '20px 34px 4px', borderTop: '1px solid rgba(255,255,255,.06)' }}>
          {ETAPAS.map((e, idx) => {
            const isDone = idx < ei || ei >= 5;
            const isCur = idx === ei && ei < 5;
            const last = idx === ETAPAS.length - 1;
            const nextDone = idx + 1 < ei || ei >= 5;
            return (
              <div key={e.key} style={{ display: 'flex', alignItems: 'center', flex: last ? 'none' : 1, minWidth: 0 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flex: 'none' }}>
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: '50%',
                      background: isDone ? e.color : '#101116',
                      border: `2px solid ${isDone ? e.color : isCur ? e.color : 'rgba(255,255,255,.14)'}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: isDone ? '#0a0b0d' : isCur ? e.color : '#3a3f48',
                    }}
                  >
                    <Icon name={isDone ? 'check' : isCur ? e.icon : 'circle'} size={15} sw={2.4} />
                  </div>
                  <span style={{ fontSize: 10.5, fontWeight: isCur ? 600 : 450, color: isDone || isCur ? 'var(--text)' : '#6f7480', whiteSpace: 'nowrap' }}>{e.short}</span>
                </div>
                {!last && <div style={{ flex: 1, height: 2, background: nextDone ? e.color : 'rgba(255,255,255,.1)', margin: '0 4px', marginBottom: 22 }} />}
              </div>
            );
          })}
        </div>

        {ei < 5 && canAdvanceFlow && (
          <div style={{ marginTop: 18, display: 'flex', alignItems: 'center', gap: 12, background: 'var(--accent-bg)', border: '1px solid rgba(214,165,42,.2)', borderRadius: 11, padding: '12px 15px' }}>
            <Icon name="target" size={18} style={{ color: 'var(--accent)' }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, fontWeight: 600 }}>Próxima ação: {p.proximaAcao}</div>
              <div style={{ fontSize: 11.5, color: '#8b909c' }}>
                Responsável: {p.adv} · Prazo {fmtDate(p.prazo)}
              </div>
            </div>
            <button
              onClick={handleAdvance}
              disabled={advancing}
              className="btn btn-accent"
              style={{ display: 'flex', alignItems: 'center', gap: 7, height: 33, padding: '0 14px', borderRadius: 8, background: 'var(--accent)', color: 'var(--accent-fg)', fontWeight: 600, fontSize: 12.5, opacity: advancing ? 0.7 : 1 }}
            >
              {advancing ? <span className="spinner" /> : null}
              Concluir etapa
              <Icon name="arrow-right" size={15} sw={2.2} />
            </button>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16, borderBottom: '1px solid rgba(255,255,255,.07)' }}>
        {TABS.map((t) => {
          const isActive = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className="btn"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 7,
                padding: '9px 12px 11px',
                fontSize: 13,
                fontWeight: isActive ? 600 : 450,
                color: isActive ? 'var(--text)' : '#8b909c',
                borderBottom: `2px solid ${isActive ? 'var(--accent)' : 'transparent'}`,
                marginBottom: -1,
              }}
            >
              <Icon name={t.icon} size={15} />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'dados' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <FieldsCard
            title="Dados do processo"
            fields={[
              { k: 'Pasta', v: p.pasta },
              { k: 'Número (CNJ)', v: p.numero },
              { k: 'Tipo', v: p.tipo },
              { k: 'Tribunal / Vara', v: p.tribunal },
              { k: 'Contrário', v: p.contrario },
              { k: 'Data de entrada', v: fmtDate(p.dataEntrada) },
              { k: 'PADM', v: p.padm },
            ]}
          />
          <FieldsCard
            title="Cliente & situação"
            fields={[
              { k: 'Cliente', v: p.cliente },
              { k: 'CNPJ / CPF', v: p.cnpj },
              { k: 'Cidade / UF', v: `${p.cidade} / ${p.estado}` },
              { k: 'Responsável', v: p.adv },
              { k: 'Etapa atual', v: em.label, color: em.color },
              { k: 'Status', v: p.status === 'ATIVO' ? 'Ativo' : 'Arquivado', color: p.status === 'ATIVO' ? '#35c28a' : '#8b909c' },
              { k: 'Prescrição', v: p.prescricao, color: p.prescricao === 'Crítico' ? '#e5644e' : p.prescricao === 'Atenção' ? '#e0a53a' : '#35c28a' },
            ]}
          />
        </div>
      )}

      {tab === 'fluxo' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
          {ETAPAS.map((e, idx) => {
            const isDone = idx < ei || ei >= 5;
            const isCur = idx === ei && ei < 5;
            const status = isDone ? 'Concluída' : isCur ? 'Em andamento' : 'Pendente';
            const color = isDone ? '#35c28a' : isCur ? e.color : '#6f7480';
            const bg = isDone ? 'rgba(53,194,138,.13)' : isCur ? e.bg : 'rgba(139,144,156,.08)';
            return (
              <div key={e.key} style={{ background: '#101116', border: `1px solid ${isCur ? e.color : 'rgba(255,255,255,.06)'}`, borderRadius: 12, padding: '15px 18px', display: 'flex', alignItems: 'center', gap: 15 }}>
                <div style={{ width: 38, height: 38, flex: 'none', borderRadius: 10, background: bg, color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={isDone ? 'check-circle' : isCur ? e.icon : 'circle'} size={19} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{e.label}</div>
                  <div style={{ fontSize: 12, color: '#8b909c', marginTop: 2 }}>{FLUXO_DESC[e.key]}</div>
                </div>
                <div style={{ textAlign: 'right', flex: 'none' }}>
                  <span style={{ fontSize: 11.5, fontWeight: 600, color, background: bg, padding: '4px 10px', borderRadius: 7 }}>{status}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'hist' && (
        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, padding: '22px 24px' }}>
          {p.historico.map((h, i) => {
            const ck = COLOR_BY_KIND[h.kind] || COLOR_BY_KIND.DONE;
            const initials = h.usuarioNome
              .replace('Dra. ', '')
              .replace('Dr. ', '')
              .split(' ')
              .map((w) => w[0])
              .slice(0, 2)
              .join('')
              .toUpperCase();
            const date = new Date(h.data);
            const hora = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
            return (
              <div key={h.id} style={{ display: 'flex', gap: 14 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 'none' }}>
                  <div style={{ width: 30, height: 30, borderRadius: 8, background: ck.b, color: ck.c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={ICON_BY_KIND[h.kind]} size={15} />
                  </div>
                  {i < p.historico.length - 1 && <div style={{ width: 2, flex: 1, background: 'rgba(255,255,255,.07)', margin: '4px 0' }} />}
                </div>
                <div style={{ flex: 1, paddingBottom: 20 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 13, fontWeight: 550 }}>{h.acao}</span>
                    <span style={{ fontSize: 11, color: '#6f7480', fontVariantNumeric: 'tabular-nums' }}>
                      {fmtDate(h.data)} · {hora}
                    </span>
                  </div>
                  <div style={{ fontSize: 12, color: '#8b909c', marginTop: 3 }}>{h.observacoes}</div>
                  <div style={{ fontSize: 11.5, color: '#6f7480', marginTop: 5, display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ width: 18, height: 18, borderRadius: 5, background: 'rgba(255,255,255,.08)', color: '#c3c7ce', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 600 }}>
                      {initials}
                    </span>
                    {h.usuarioNome}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'obs' && (
        <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, padding: '20px 22px' }}>
          <h3 style={{ marginBottom: 12, fontSize: 13, fontWeight: 600 }}>Observações do processo</h3>
          <p style={{ fontSize: 13.5, lineHeight: 1.7, color: '#c3c7ce' }}>{p.observacoes}</p>
          <div style={{ marginTop: 18, paddingTop: 18, borderTop: '1px solid rgba(255,255,255,.06)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div style={{ fontSize: 12.5, color: '#8b909c' }}>
              Valor da causa: <b style={{ color: 'var(--text)' }}>{money(p.valorCausa)}</b>
            </div>
            <div style={{ fontSize: 12.5, color: '#8b909c' }}>
              Valor do crédito: <b style={{ color: 'var(--text)' }}>{money(p.valorCredito)}</b>
            </div>
            <div style={{ fontSize: 12.5, color: '#8b909c' }}>
              Habilitado: <b style={{ color: 'var(--text)' }}>{money(p.valorHabilitado)}</b>
            </div>
            <div style={{ fontSize: 12.5, color: '#8b909c' }}>
              Compensado: <b style={{ color: 'var(--text)' }}>{money(p.valorCompensado)}</b>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FieldsCard({ title, fields }: { title: string; fields: { k: string; v: string; color?: string }[] }) {
  return (
    <div style={{ background: '#101116', border: '1px solid rgba(255,255,255,.06)', borderRadius: 13, padding: '18px 20px' }}>
      <h3 style={{ marginBottom: 14, fontSize: 12.5, fontWeight: 600, color: '#8b909c', textTransform: 'uppercase', letterSpacing: '.5px' }}>{title}</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {fields.map((f) => (
          <div key={f.k} style={{ display: 'flex', justifyContent: 'space-between', gap: 16 }}>
            <span style={{ fontSize: 12.5, color: '#8b909c', flex: 'none' }}>{f.k}</span>
            <span style={{ fontSize: 12.5, fontWeight: 500, textAlign: 'right', color: f.color }}>{f.v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
