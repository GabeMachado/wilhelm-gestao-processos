import { Icon } from '../lib/icons';

export default function BlankPage({ title, icon }: { title: string; icon: string }) {
  return (
    <div className="anim-fade" style={{ padding: '26px 28px 50px', maxWidth: 1120 }}>
      <h1 style={{ margin: 0, fontSize: 23, fontWeight: 600, letterSpacing: '-.3px' }}>{title}</h1>
      <div
        style={{
          marginTop: 40,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 10,
          padding: '80px 20px',
          border: '1px dashed rgba(255,255,255,.1)',
          borderRadius: 14,
          color: '#6f7480',
        }}
      >
        <Icon name={icon} size={30} style={{ color: '#3a3f48' }} />
        <div style={{ fontSize: 13 }}>Esta área ainda não foi projetada.</div>
      </div>
    </div>
  );
}
