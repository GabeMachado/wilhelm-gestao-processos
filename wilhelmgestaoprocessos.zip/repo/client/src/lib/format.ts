import type { Etapa, Resultado } from './types';

export const ETAPAS: { key: Etapa; label: string; short: string; color: string; bg: string; icon: string }[] = [
  { key: 'ENTRADA', label: 'Entrada', short: 'Entrada', color: '#8b909c', bg: 'rgba(139,144,156,.14)', icon: 'inbox' },
  { key: 'DOCUMENTOS', label: 'Documentos & Procuração', short: 'Documentos', color: '#5b8def', bg: 'rgba(91,141,239,.15)', icon: 'file' },
  { key: 'HABILITACAO', label: 'Habilitação', short: 'Habilitação', color: '#8b7bd8', bg: 'rgba(139,123,216,.15)', icon: 'gavel' },
  { key: 'COMPENSACAO', label: 'Compensação', short: 'Compensação', color: '#3bc0c8', bg: 'rgba(59,192,200,.15)', icon: 'receipt' },
  { key: 'HONORARIOS', label: 'Honorários', short: 'Honorários', color: '#e0a53a', bg: 'rgba(224,165,58,.15)', icon: 'banknote' },
  { key: 'ENCERRADO', label: 'Encerrado', short: 'Encerrado', color: '#35c28a', bg: 'rgba(53,194,138,.15)', icon: 'check-circle' },
];
export const EK: Etapa[] = ETAPAS.map((e) => e.key);
export function etapaIndex(e: Etapa) {
  return EK.indexOf(e);
}
export function emeta(e: Etapa) {
  return ETAPAS[etapaIndex(e)] ?? ETAPAS[0];
}

export const RESULTADO_LABEL: Record<Resultado, string> = {
  EM_ANDAMENTO: 'Em andamento',
  EXITO_TOTAL: 'Êxito Total',
  EXITO_PARCIAL: 'Êxito Parcial',
  PERDA: 'Perda',
};
export const RESULTADO_COLOR: Record<Resultado, string> = {
  EM_ANDAMENTO: '#8b909c',
  EXITO_TOTAL: '#35c28a',
  EXITO_PARCIAL: '#3bc0c8',
  PERDA: '#e5644e',
};

export function tipoMeta(tipo: string) {
  if (tipo === 'Mandado de Segurança') return { s: 'MS', color: '#5b8def', bg: 'rgba(91,141,239,.14)' };
  if (tipo === 'Cumprimento de Sentença') return { s: 'Cump.', color: '#8b7bd8', bg: 'rgba(139,123,216,.14)' };
  if (tipo === 'Ação Ordinária') return { s: 'Ord.', color: '#3bc0c8', bg: 'rgba(59,192,200,.14)' };
  return { s: 'Decl.', color: '#e0a53a', bg: 'rgba(224,165,58,.14)' };
}

export function fmtDate(d: string | Date | null | undefined): string {
  if (!d) return '—';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return '—';
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(date.getDate())}/${p(date.getMonth() + 1)}/${date.getFullYear()}`;
}

export function toIsoDateInput(d: string | Date | null | undefined): string {
  if (!d) return '';
  const date = typeof d === 'string' ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return '';
  const p = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}`;
}

export function daysBetween(a: Date, b: Date): number {
  return Math.round((a.getTime() - b.getTime()) / 86400000);
}

export function money(n: number, masked = false): string {
  if (masked) return 'R$ ••••';
  return 'R$ ' + Number(n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function moneyShort(n: number, masked = false): string {
  if (masked) return 'R$ ••';
  const v = Number(n || 0);
  if (v >= 1e6) return 'R$ ' + (v / 1e6).toFixed(1).replace('.', ',') + 'M';
  if (v >= 1e3) return 'R$ ' + Math.round(v / 1e3) + 'k';
  return 'R$ ' + v;
}

export function diasView(etapa: Etapa, prazo: string | null): { txt: string; color: string } {
  if (etapaIndex(etapa) >= 5) return { txt: 'Encerrado', color: '#35c28a' };
  if (!prazo) return { txt: '—', color: '#8b909c' };
  const dias = daysBetween(new Date(prazo), new Date());
  if (dias < 0) return { txt: Math.abs(dias) + 'd atraso', color: '#e5644e' };
  if (dias <= 7) return { txt: dias + 'd restam', color: '#e0a53a' };
  return { txt: dias + 'd restam', color: '#8b909c' };
}
