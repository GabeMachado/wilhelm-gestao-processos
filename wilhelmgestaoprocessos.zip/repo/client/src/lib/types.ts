export type Role = 'ADMIN' | 'ADVOGADO' | 'ASSISTENTE' | 'FINANCEIRO';
export type Etapa = 'ENTRADA' | 'DOCUMENTOS' | 'HABILITACAO' | 'COMPENSACAO' | 'HONORARIOS' | 'ENCERRADO';
export type StatusProcesso = 'ATIVO' | 'ARQUIVADO';
export type Resultado = 'EM_ANDAMENTO' | 'EXITO_TOTAL' | 'EXITO_PARCIAL' | 'PERDA';
export type MovimentacaoKind = 'CREATE' | 'DONE' | 'CURRENT' | 'EDIT' | 'MOVE' | 'DELETE';

export interface User {
  id: string;
  nome: string;
  email: string;
  role: Role;
  initials: string;
  color: string;
  bg: string;
}

export interface Processo {
  id: string;
  pasta: string;
  numero: string;
  tipo: string;
  cliente: string;
  cnpj: string;
  cidade: string;
  estado: string;
  contrario: string;
  tese: string;
  teseTag: string;
  tribunal: string;
  adv: string;
  advId: string;
  dataEntrada: string;
  valorCausa: number;
  valorCredito: number;
  valorHabilitado: number;
  valorCompensado: number;
  honContratual: number;
  honSucumb: number;
  etapa: Etapa;
  status: StatusProcesso;
  resultado: Resultado;
  proximaAcao: string;
  prazo: string | null;
  padm: string;
  transito: string;
  prescricao: string;
  observacoes: string;
  updatedAt: string;
}

export interface Movimentacao {
  id: string;
  processoId: string;
  usuarioNome: string;
  acao: string;
  observacoes: string;
  kind: MovimentacaoKind;
  data: string;
}

export interface ProcessoDetail extends Processo {
  historico: Movimentacao[];
}

export interface DashboardData {
  metrics: { label: string; value: number; isMoney?: boolean; icon: string; color: string; bg: string }[];
  pendencias: { key: string; label: string; count: number; icon: string; color: string }[];
  barEtapa: { label: string; count: number; pct: number; color: string }[];
  resultadoLegend: { label: string; count: number; color: string }[];
  exitoPct: number;
  barMes: { label: string; entradas: number; encerrados: number; hEnt: number; hEnc: number }[];
  barResp: { name: string; initials: string; color: string; bg: string; count: number; pct: number }[];
  prazos: { pid: string; cliente: string; acao: string; prazo: string; dias: number }[];
  recentAtiv: { kind: MovimentacaoKind; user: string; text: string; cliente: string; when: string }[];
}

export interface TeamMember {
  id: string;
  nome: string;
  email: string;
  role: Role;
  roleLabel: string;
  roleColor: string;
  roleBg: string;
  initials: string;
  color: string;
  bg: string;
  online: boolean;
  count: number;
}

export interface TeamData {
  team: TeamMember[];
  roles: { key: Role; label: string; color: string; bg: string; desc: string; count: number }[];
  teamCount: number;
}

export interface PermissionsData {
  roles: { key: Role; label: string; color: string }[];
  rows: { key: string; label: string; roles: Role[] }[];
}
