import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, ApiError } from '../lib/api';
import type { User } from '../lib/types';

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get<User>('/auth/me')
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const u = await api.post<User>('/auth/login', { email, password });
    setUser(u);
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } catch (e) {
      if (!(e instanceof ApiError)) throw e;
    }
    setUser(null);
  }, []);

  return <AuthContext.Provider value={{ user, loading, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

const PERMISSION_ROLES: Record<string, string[]> = {
  VIEW_PROCESSES: ['ADMIN', 'ADVOGADO', 'ASSISTENTE', 'FINANCEIRO'],
  EDIT_PROCESSES: ['ADMIN', 'ADVOGADO', 'ASSISTENTE'],
  DELETE_PROCESSES: ['ADMIN'],
  ADVANCE_FLOW: ['ADMIN', 'ADVOGADO', 'ASSISTENTE'],
  MANAGE_FINANCE: ['ADMIN', 'FINANCEIRO'],
  IMPORT_EXPORT: ['ADMIN', 'ADVOGADO', 'FINANCEIRO'],
  MANAGE_TEAM: ['ADMIN'],
  VIEW_AUDIT: ['ADMIN', 'FINANCEIRO'],
};

export function useCan(permission: keyof typeof PERMISSION_ROLES): boolean {
  const { user } = useAuth();
  if (!user) return false;
  return PERMISSION_ROLES[permission].includes(user.role);
}
