import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api } from '../lib/api';
import type { Etapa, Processo } from '../lib/types';

export interface Filters {
  search: string;
  etapa: Etapa | '';
  resp: string;
  tipo: string;
  status: string;
}

const EMPTY_FILTERS: Filters = { search: '', etapa: '', resp: '', tipo: '', status: '' };

interface ProcessesContextValue {
  processes: Processo[];
  loading: boolean;
  filters: Filters;
  setFilters: (f: Partial<Filters>) => void;
  clearFilters: () => void;
  filtered: Processo[];
  refresh: () => Promise<void>;
  upsertLocal: (p: Processo) => void;
  removeLocal: (id: string) => void;
}

const ProcessesContext = createContext<ProcessesContextValue | null>(null);

export function ProcessesProvider({ children }: { children: ReactNode }) {
  const [processes, setProcesses] = useState<Processo[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFiltersState] = useState<Filters>(EMPTY_FILTERS);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const rows = await api.get<Processo[]>('/processos');
      setProcesses(rows);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const setFilters = useCallback((f: Partial<Filters>) => {
    setFiltersState((prev) => ({ ...prev, ...f }));
  }, []);
  const clearFilters = useCallback(() => setFiltersState(EMPTY_FILTERS), []);

  const upsertLocal = useCallback((p: Processo) => {
    setProcesses((prev) => {
      const idx = prev.findIndex((x) => x.id === p.id);
      if (idx === -1) return [p, ...prev];
      const next = prev.slice();
      next[idx] = p;
      return next;
    });
  }, []);
  const removeLocal = useCallback((id: string) => {
    setProcesses((prev) => prev.filter((x) => x.id !== id));
  }, []);

  const filtered = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return processes.filter((p) => {
      if (filters.etapa && p.etapa !== filters.etapa) return false;
      if (filters.resp && p.adv !== filters.resp) return false;
      if (filters.tipo && p.tipo !== filters.tipo) return false;
      if (filters.status && p.status !== filters.status) return false;
      if (q) {
        const hay = `${p.cliente} ${p.numero} ${p.cnpj} ${p.tese} ${p.pasta} ${p.adv}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [processes, filters]);

  return (
    <ProcessesContext.Provider
      value={{ processes, loading, filters, setFilters, clearFilters, filtered, refresh, upsertLocal, removeLocal }}
    >
      {children}
    </ProcessesContext.Provider>
  );
}

export function useProcesses(): ProcessesContextValue {
  const ctx = useContext(ProcessesContext);
  if (!ctx) throw new Error('useProcesses must be used within ProcessesProvider');
  return ctx;
}
