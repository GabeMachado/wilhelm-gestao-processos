import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';
import { Icon } from '../lib/icons';

type ToastKind = 'ok' | 'warn' | 'danger';
interface Toast {
  msg: string;
  kind: ToastKind;
}
const META: Record<ToastKind, { icon: string; color: string; bg: string }> = {
  ok: { icon: 'check', color: '#35c28a', bg: 'rgba(53,194,138,.16)' },
  warn: { icon: 'alert', color: '#e0a53a', bg: 'rgba(224,165,58,.16)' },
  danger: { icon: 'trash', color: '#e5644e', bg: 'rgba(229,100,78,.16)' },
};

const ToastContext = createContext<((msg: string, kind?: ToastKind) => void) | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<Toast | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const flash = useCallback((msg: string, kind: ToastKind = 'ok') => {
    setToast({ msg, kind });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 2600);
  }, []);

  const meta = toast ? META[toast.kind] : null;

  return (
    <ToastContext.Provider value={flash}>
      {children}
      {toast && meta && (
        <div
          className="anim-slideup"
          style={{
            position: 'fixed',
            bottom: 24,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 120,
            display: 'flex',
            alignItems: 'center',
            gap: 11,
            background: '#1a1d24',
            border: '1px solid rgba(255,255,255,.12)',
            borderRadius: 11,
            padding: '12px 17px',
            boxShadow: '0 14px 40px rgba(0,0,0,.5)',
          }}
        >
          <div
            style={{
              width: 24,
              height: 24,
              borderRadius: 7,
              background: meta.bg,
              color: meta.color,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flex: 'none',
            }}
          >
            <Icon name={meta.icon} size={14} sw={2.4} />
          </div>
          <span style={{ fontSize: 13, fontWeight: 500 }}>{toast.msg}</span>
        </div>
      )}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
