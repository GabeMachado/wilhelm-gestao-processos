import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import type { Processo } from '../lib/types';

export type DrawerState = { mode: 'new' } | { mode: 'edit'; processo: Processo } | null;

interface UIContextValue {
  drawer: DrawerState;
  openNewDrawer: () => void;
  openEditDrawer: (p: Processo) => void;
  closeDrawer: () => void;

  importOpen: boolean;
  openImport: () => void;
  closeImport: () => void;

  confirmDeleteId: string | null;
  askDelete: (id: string) => void;
  cancelDelete: () => void;

  commandOpen: boolean;
  openCommand: () => void;
  closeCommand: () => void;
  toggleCommand: () => void;

  notifOpen: boolean;
  toggleNotif: () => void;
  closeNotif: () => void;
}

const UIContext = createContext<UIContextValue | null>(null);

export function UIProvider({ children }: { children: ReactNode }) {
  const [drawer, setDrawer] = useState<DrawerState>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [commandOpen, setCommandOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const value: UIContextValue = {
    drawer,
    openNewDrawer: () => setDrawer({ mode: 'new' }),
    openEditDrawer: (p) => setDrawer({ mode: 'edit', processo: p }),
    closeDrawer: () => setDrawer(null),

    importOpen,
    openImport: () => setImportOpen(true),
    closeImport: () => setImportOpen(false),

    confirmDeleteId,
    askDelete: (id) => setConfirmDeleteId(id),
    cancelDelete: () => setConfirmDeleteId(null),

    commandOpen,
    openCommand: useCallback(() => setCommandOpen(true), []),
    closeCommand: useCallback(() => setCommandOpen(false), []),
    toggleCommand: useCallback(() => setCommandOpen((v) => !v), []),

    notifOpen,
    toggleNotif: useCallback(() => setNotifOpen((v) => !v), []),
    closeNotif: useCallback(() => setNotifOpen(false), []),
  };

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI(): UIContextValue {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error('useUI must be used within UIProvider');
  return ctx;
}
