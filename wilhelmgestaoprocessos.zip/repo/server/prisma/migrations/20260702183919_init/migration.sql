-- CreateEnum
CREATE TYPE "Role" AS ENUM ('ADMIN', 'ADVOGADO', 'ASSISTENTE', 'FINANCEIRO');

-- CreateEnum
CREATE TYPE "Etapa" AS ENUM ('ENTRADA', 'DOCUMENTOS', 'HABILITACAO', 'COMPENSACAO', 'HONORARIOS', 'ENCERRADO');

-- CreateEnum
CREATE TYPE "StatusProcesso" AS ENUM ('ATIVO', 'ARQUIVADO');

-- CreateEnum
CREATE TYPE "Resultado" AS ENUM ('EM_ANDAMENTO', 'EXITO_TOTAL', 'EXITO_PARCIAL', 'PERDA');

-- CreateEnum
CREATE TYPE "MovimentacaoKind" AS ENUM ('CREATE', 'DONE', 'CURRENT', 'EDIT', 'MOVE', 'DELETE');

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "role" "Role" NOT NULL,
    "initials" TEXT NOT NULL,
    "color" TEXT NOT NULL,
    "bg" TEXT NOT NULL,
    "online" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Cliente" (
    "id" TEXT NOT NULL,
    "nome" TEXT NOT NULL,
    "cnpjCpf" TEXT NOT NULL,
    "cidade" TEXT NOT NULL,
    "estado" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Cliente_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Processo" (
    "id" TEXT NOT NULL,
    "pasta" TEXT NOT NULL,
    "numero" TEXT NOT NULL,
    "tipo" TEXT NOT NULL,
    "clienteId" TEXT NOT NULL,
    "contrario" TEXT NOT NULL,
    "tese" TEXT NOT NULL,
    "teseTag" TEXT NOT NULL,
    "tribunal" TEXT NOT NULL,
    "estado" TEXT NOT NULL,
    "cidade" TEXT NOT NULL,
    "advogadoId" TEXT NOT NULL,
    "dataEntrada" TIMESTAMP(3) NOT NULL,
    "valorCausa" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "valorCredito" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "valorHabilitado" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "valorCompensado" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "honContratual" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "honSucumb" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "etapa" "Etapa" NOT NULL DEFAULT 'ENTRADA',
    "status" "StatusProcesso" NOT NULL DEFAULT 'ATIVO',
    "resultado" "Resultado" NOT NULL DEFAULT 'EM_ANDAMENTO',
    "proximaAcao" TEXT NOT NULL,
    "prazo" TIMESTAMP(3),
    "padm" TEXT NOT NULL DEFAULT '—',
    "transito" TEXT NOT NULL DEFAULT '—',
    "prescricao" TEXT NOT NULL DEFAULT 'Regular',
    "observacoes" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Processo_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Movimentacao" (
    "id" TEXT NOT NULL,
    "processoId" TEXT NOT NULL,
    "usuarioId" TEXT,
    "usuarioNome" TEXT NOT NULL,
    "acao" TEXT NOT NULL,
    "observacoes" TEXT NOT NULL,
    "kind" "MovimentacaoKind" NOT NULL,
    "data" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Movimentacao_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Cliente_nome_cnpjCpf_key" ON "Cliente"("nome", "cnpjCpf");

-- CreateIndex
CREATE UNIQUE INDEX "Processo_pasta_key" ON "Processo"("pasta");

-- AddForeignKey
ALTER TABLE "Processo" ADD CONSTRAINT "Processo_clienteId_fkey" FOREIGN KEY ("clienteId") REFERENCES "Cliente"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Processo" ADD CONSTRAINT "Processo_advogadoId_fkey" FOREIGN KEY ("advogadoId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Movimentacao" ADD CONSTRAINT "Movimentacao_processoId_fkey" FOREIGN KEY ("processoId") REFERENCES "Processo"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Movimentacao" ADD CONSTRAINT "Movimentacao_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
