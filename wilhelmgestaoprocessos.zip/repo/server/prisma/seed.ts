import { Etapa, MovimentacaoKind, PrismaClient, Resultado, StatusProcesso } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// deterministic PRNG so the seeded data is stable across runs (mirrors the design prototype)
const RNG = (function (a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
})(20240702);
function R<T>(arr: T[]): T {
  return arr[Math.floor(RNG() * arr.length)];
}

const NOW = new Date();

const EK: Etapa[] = ['ENTRADA', 'DOCUMENTOS', 'HABILITACAO', 'COMPENSACAO', 'HONORARIOS', 'ENCERRADO'];
const EMETA: Record<Etapa, { label: string }> = {
  ENTRADA: { label: 'Entrada' },
  DOCUMENTOS: { label: 'Documentos & Procuração' },
  HABILITACAO: { label: 'Habilitação' },
  COMPENSACAO: { label: 'Compensação' },
  HONORARIOS: { label: 'Honorários' },
  ENCERRADO: { label: 'Encerrado' },
};

const USERS = [
  { nome: 'Dra. Camila Wilhelm', email: 'camila@wilhelm.adv.br', initials: 'CW', color: '#d6a52a', bg: 'rgba(214,165,42,.16)', role: 'ADMIN' as const },
  { nome: 'Dr. Rafael Nogueira', email: 'rafael@wilhelm.adv.br', initials: 'RN', color: '#5b8def', bg: 'rgba(91,141,239,.16)', role: 'ADVOGADO' as const },
  { nome: 'Dr. Marcos Steil', email: 'marcos@wilhelm.adv.br', initials: 'MS', color: '#35c28a', bg: 'rgba(53,194,138,.16)', role: 'ADVOGADO' as const },
  { nome: 'Dra. Daniela Prux', email: 'daniela@wilhelm.adv.br', initials: 'DP', color: '#8b7bd8', bg: 'rgba(139,123,216,.16)', role: 'ASSISTENTE' as const },
  { nome: 'Júlia Bauer', email: 'julia@wilhelm.adv.br', initials: 'JB', color: '#e0863a', bg: 'rgba(224,134,58,.16)', role: 'ASSISTENTE' as const },
  { nome: 'Paulo Reif', email: 'paulo@wilhelm.adv.br', initials: 'PR', color: '#e5644e', bg: 'rgba(229,100,78,.16)', role: 'FINANCEIRO' as const },
];
const DEMO_PASSWORD = 'senha-demo';

const CLIENTES = [
  { nome: 'Têxtil Vale do Itajaí Ltda', cid: 'Blumenau', uf: 'SC' },
  { nome: 'Malhas Blumenau Indústria S.A.', cid: 'Blumenau', uf: 'SC' },
  { nome: 'Metalúrgica Joinville Norte Ltda', cid: 'Joinville', uf: 'SC' },
  { nome: 'Plásticos Itajaí Indústria EIRELI', cid: 'Itajaí', uf: 'SC' },
  { nome: 'Alimentos Brusque Comércio Ltda', cid: 'Brusque', uf: 'SC' },
  { nome: 'Madeireira Rio do Sul Ltda', cid: 'Rio do Sul', uf: 'SC' },
  { nome: 'Confecções Gaspar Moda Ltda', cid: 'Gaspar', uf: 'SC' },
  { nome: 'Frigorífico Chapecó Oeste S.A.', cid: 'Chapecó', uf: 'SC' },
  { nome: 'Eletro Componentes Timbó Ltda', cid: 'Timbó', uf: 'SC' },
  { nome: 'Química Pomerode Industrial Ltda', cid: 'Pomerode', uf: 'SC' },
  { nome: 'Embalagens Indaial Comércio Ltda', cid: 'Indaial', uf: 'SC' },
  { nome: 'Calçados Jaraguá Sul Ltda', cid: 'Jaraguá do Sul', uf: 'SC' },
  { nome: 'Tecelagem Brusque Têxtil S.A.', cid: 'Brusque', uf: 'SC' },
  { nome: 'Motores Elétricos Blumenau Ltda', cid: 'Blumenau', uf: 'SC' },
  { nome: 'Transportes Navegantes Log Ltda', cid: 'Navegantes', uf: 'SC' },
  { nome: 'Agroindústria Concórdia Ltda', cid: 'Concórdia', uf: 'SC' },
  { nome: 'Bebidas Vale Europeu Distrib. Ltda', cid: 'Pomerode', uf: 'SC' },
  { nome: 'Cerâmica Criciúma Sul Ltda', cid: 'Criciúma', uf: 'SC' },
];

const TESES = [
  { t: 'PIS/COFINS – Exclusão do ICMS da base de cálculo do PIS/COFINS', tag: 'Tese do Século' },
  { t: 'SELIC – Não incidência de IRPJ/CSLL sobre as atualizações SELIC', tag: 'SELIC' },
  { t: 'INSS – Não incidência sobre verbas de natureza indenizatória', tag: 'INSS' },
  { t: 'Energia Elétrica – Exclusão da TUST e TUSD da base do ICMS', tag: 'Energia' },
  { t: 'IRPJ – Inadmissibilidade de limites de dedução por refeição (PAT)', tag: 'IRPJ' },
  { t: 'SISCOMEX – Majoração ilegal das taxas por portaria', tag: 'SISCOMEX' },
  { t: 'PIS/COFINS – Ampliação do direito ao crédito não cumulativo', tag: 'PIS/COFINS' },
  { t: 'INSS – Exclusão de retenções (IRRF/INSS) e descontos (VT/VA) da base', tag: 'INSS' },
];
const CONTRARIOS = [
  'Delegado da Receita Federal do Brasil – Blumenau',
  'Delegado da Receita Federal do Brasil – Joinville',
  'Delegado da Receita Federal do Brasil – Florianópolis',
  'União – Fazenda Nacional',
];
const TIPOS = ['Mandado de Segurança', 'Mandado de Segurança', 'Cumprimento de Sentença', 'Cumprimento de Sentença', 'Ação Ordinária', 'Ação Declaratória'];

const STAGE_SEQ: number[] = [5, 5, 5, 5, 4, 4, 4, 3, 3, 3, 2, 2, 2, 1, 1, 1, 0, 0, 5, 4, 3, 2, 5, 4, 3, 2, 1, 5, 4, 3, 2, 1];

function daysBetween(a: Date, b: Date) {
  return Math.round((a.getTime() - b.getTime()) / 86400000);
}

async function main() {
  console.log('Seeding database...');

  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const userRecords = [];
  for (const u of USERS) {
    const rec = await prisma.user.upsert({
      where: { email: u.email },
      update: {},
      create: { ...u, passwordHash, online: RNG() > 0.4 },
    });
    userRecords.push(rec);
  }
  const advogados = userRecords.filter((u) => u.role === 'ADVOGADO' || u.role === 'ADMIN');

  const clienteRecords = [];
  for (const c of CLIENTES) {
    const cnpj = `${10 + clienteRecords.length}.${(300 + clienteRecords.length * 7).toString().slice(0, 3)}.${(400 + clienteRecords.length * 3)
      .toString()
      .slice(0, 3)}/0001-${String(10 + (clienteRecords.length % 80)).padStart(2, '0')}`;
    const rec = await prisma.cliente.upsert({
      where: { nome_cnpjCpf: { nome: c.nome, cnpjCpf: cnpj } },
      update: {},
      create: { nome: c.nome, cnpjCpf: cnpj, cidade: c.cid, estado: c.uf },
    });
    clienteRecords.push(rec);
  }

  await prisma.movimentacao.deleteMany({});
  await prisma.processo.deleteMany({});

  for (let i = 0; i < STAGE_SEQ.length; i++) {
    const cli = clienteRecords[i % clienteRecords.length];
    const tese = TESES[(i * 5 + 3) % TESES.length];
    const tipo = TIPOS[(i * 3 + 1) % TIPOS.length];
    const adv = advogados[i % advogados.length];
    const ei = STAGE_SEQ[i];
    const etapa = EK[ei];

    const entrY = 2016 + Math.floor(RNG() * 7);
    const dataEntrada = new Date(entrY, Math.floor(RNG() * 12), 1 + Math.floor(RNG() * 27));
    const valorCausa = Math.round((60000 + RNG() * 3400000) / 1000) * 1000;
    const valorCredito = Math.round((valorCausa * (0.45 + RNG() * 0.4)) / 1000) * 1000;
    const valorHabilitado = ei >= 2 ? Math.round(valorCredito * (0.8 + RNG() * 0.2)) : 0;
    const valorCompensado = ei >= 3 ? Math.round(valorHabilitado * (ei >= 4 ? 0.6 + RNG() * 0.4 : 0.2 + RNG() * 0.35)) : 0;
    const honContratual = Math.round(valorCredito * (0.1 + RNG() * 0.1));
    const honSucumb = RNG() > 0.5 ? Math.round(valorCausa * (0.05 + RNG() * 0.05)) : 0;

    const stageDates: Partial<Record<Etapa, Date>> = {};
    let cursor = new Date(dataEntrada);
    for (let s = 0; s <= ei; s++) {
      cursor = new Date(cursor.getTime() + (30 + RNG() * 220) * 86400000);
      if (cursor > NOW) cursor = new Date(NOW.getTime() - RNG() * 40 * 86400000);
      stageDates[EK[s]] = new Date(cursor);
    }
    const atualizado = ei >= 5 ? stageDates.ENCERRADO! : new Date(NOW.getTime() - Math.floor(RNG() * 70) * 86400000);
    let prazo: Date | null = null;
    if (ei < 5) {
      const off = Math.floor(-12 + RNG() * 55);
      prazo = new Date(NOW.getTime() + off * 86400000);
    }
    const encerrado = ei >= 5;
    const resultado: Resultado = encerrado ? (RNG() > 0.78 ? 'EXITO_PARCIAL' : RNG() > 0.9 ? 'PERDA' : 'EXITO_TOTAL') : 'EM_ANDAMENTO';
    const proxByEtapa: Record<Etapa, string> = {
      ENTRADA: 'Cadastrar no sistema e dar CCR',
      DOCUMENTOS: 'Cobrar documentos e procuração assinada',
      HABILITACAO: 'Cálculo com Daniela / habilitar crédito',
      COMPENSACAO: 'Transmitir PER/DCOMP e acompanhar',
      HONORARIOS: 'Cobrar honorários contratuais',
      ENCERRADO: '—',
    };

    const numero = `500${(1000 + i * 131).toString().slice(0, 4)}-${10 + i}.20${16 + (i % 7)}.4.04.72${String(1 + (i % 9)).padStart(2, '0')}`;
    const cnpj = `${10 + i}.${(300 + i * 7).toString().slice(0, 3)}.${(400 + i * 3).toString().slice(0, 3)}/0001-${String(10 + (i % 80)).padStart(2, '0')}`;

    const processo = await prisma.processo.create({
      data: {
        pasta: 'Proc - ' + String(1000 + i * 7 + 3).padStart(7, '0'),
        numero,
        tipo,
        clienteId: cli.id,
        contrario: CONTRARIOS[i % CONTRARIOS.length],
        tese: tese.t,
        teseTag: tese.tag,
        tribunal: `TRF4 · ${(i % 3) + 1}ª Vara Federal de ${cli.cidade}`,
        estado: cli.estado,
        cidade: cli.cidade,
        advogadoId: adv.id,
        dataEntrada,
        valorCausa,
        valorCredito,
        valorHabilitado,
        valorCompensado,
        honContratual,
        honSucumb,
        etapa,
        status: encerrado ? StatusProcesso.ARQUIVADO : StatusProcesso.ATIVO,
        resultado,
        proximaAcao: proxByEtapa[etapa],
        prazo,
        padm: ei >= 2 ? `101${66 + i}.${700000 + i * 13}/20${20 + (i % 4)}-${10 + (i % 80)}` : '—',
        transito: ei >= 1 ? (stageDates.DOCUMENTOS ?? dataEntrada).toISOString() : '—',
        prescricao: prazo && daysBetween(prazo, NOW) < 0 ? 'Crítico' : prazo && daysBetween(prazo, NOW) < 10 ? 'Atenção' : 'Regular',
        observacoes: `Cliente ${cli.nome} (${cli.cidade}/${cli.estado}). Tese: ${tese.tag}. ` +
          (encerrado
            ? `Processo encerrado com ${resultado.replace('_', ' ').toLowerCase()}; verificar eventual prescrição do crédito remanescente.`
            : `Acompanhar ${EMETA[etapa].label.toLowerCase()}. ${proxByEtapa[etapa]}.`),
      },
    });

    // historico
    const histEntries: { t: Date; usuarioId: string; usuarioNome: string; acao: string; obs: string; kind: MovimentacaoKind }[] = [];
    histEntries.push({
      t: dataEntrada,
      usuarioId: userRecords.find((u) => u.nome === 'Júlia Bauer')!.id,
      usuarioNome: 'Júlia Bauer',
      acao: 'Processo cadastrado',
      obs: 'Cadastro inicial a partir de ' + tipo + '.',
      kind: 'CREATE',
    });
    for (let s = 1; s <= ei; s++) {
      const stageKey = EK[s];
      const respUser = s === 2 ? userRecords.find((u) => u.nome === 'Dra. Daniela Prux')! : adv;
      const descByEtapa: Record<Etapa, string> = {
        ENTRADA: 'Concluída.',
        DOCUMENTOS: 'Documentos e procuração recebidos e conferidos.',
        HABILITACAO: 'Crédito habilitado após cálculo de liquidação.',
        COMPENSACAO: 'Compensação transmitida via PER/DCOMP.',
        HONORARIOS: 'Honorários contratuais quitados pelo cliente.',
        ENCERRADO: 'Processo arquivado com êxito.',
      };
      histEntries.push({
        t: stageDates[stageKey]!,
        usuarioId: respUser.id,
        usuarioNome: respUser.nome,
        acao: 'Etapa concluída · ' + EMETA[stageKey].label,
        obs: descByEtapa[stageKey],
        kind: 'DONE',
      });
    }
    if (ei < 5) {
      histEntries.push({
        t: atualizado,
        usuarioId: adv.id,
        usuarioNome: adv.nome,
        acao: 'Em andamento · ' + EMETA[etapa].label,
        obs: proxByEtapa[etapa],
        kind: 'CURRENT',
      });
    }

    await prisma.movimentacao.createMany({
      data: histEntries.map((h) => ({
        processoId: processo.id,
        usuarioId: h.usuarioId,
        usuarioNome: h.usuarioNome,
        acao: h.acao,
        observacoes: h.obs,
        kind: h.kind,
        data: h.t,
      })),
    });

    // keep updatedAt aligned with the "last touched" moment for realistic dashboards
    await prisma.processo.update({ where: { id: processo.id }, data: { updatedAt: atualizado } });
  }

  console.log(`Seed complete: ${userRecords.length} usuários, ${clienteRecords.length} clientes, ${STAGE_SEQ.length} processos.`);
  console.log(`Login de demonstração: qualquer e-mail acima · senha "${DEMO_PASSWORD}"`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
