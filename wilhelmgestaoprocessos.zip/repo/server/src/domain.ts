import { Etapa } from '@prisma/client';

export const ETAPAS: { key: Etapa; label: string; short: string; color: string; bg: string; icon: string }[] = [
  { key: 'ENTRADA', label: 'Entrada', short: 'Entrada', color: '#8b909c', bg: 'rgba(139,144,156,.14)', icon: 'inbox' },
  { key: 'DOCUMENTOS', label: 'Documentos & Procuração', short: 'Documentos', color: '#5b8def', bg: 'rgba(91,141,239,.15)', icon: 'file' },
  { key: 'HABILITACAO', label: 'Habilitação', short: 'Habilitação', color: '#8b7bd8', bg: 'rgba(139,123,216,.15)', icon: 'gavel' },
  { key: 'COMPENSACAO', label: 'Compensação', short: 'Compensação', color: '#3bc0c8', bg: 'rgba(59,192,200,.15)', icon: 'receipt' },
  { key: 'HONORARIOS', label: 'Honorários', short: 'Honorários', color: '#e0a53a', bg: 'rgba(224,165,58,.15)', icon: 'banknote' },
  { key: 'ENCERRADO', label: 'Encerrado', short: 'Encerrado', color: '#35c28a', bg: 'rgba(53,194,138,.15)', icon: 'check-circle' },
];

export const EK: Etapa[] = ETAPAS.map((e) => e.key);

export function etapaIndex(e: Etapa): number {
  return EK.indexOf(e);
}

export function emeta(e: Etapa) {
  return ETAPAS[etapaIndex(e)] ?? ETAPAS[0];
}

export function nextEtapa(e: Etapa): Etapa | null {
  const i = etapaIndex(e);
  return i < EK.length - 1 ? EK[i + 1] : null;
}

export const PROXIMA_ACAO_POR_ETAPA: Record<Etapa, string> = {
  ENTRADA: 'Cobrar documentos e procuração',
  DOCUMENTOS: 'Cálculo com Daniela / habilitar',
  HABILITACAO: 'Transmitir PER/DCOMP',
  COMPENSACAO: 'Cobrar honorários contratuais',
  HONORARIOS: 'Aguardar quitação e encerrar',
  ENCERRADO: '—',
};

export function daysBetween(a: Date, b: Date): number {
  return Math.round((a.getTime() - b.getTime()) / 86400000);
}
