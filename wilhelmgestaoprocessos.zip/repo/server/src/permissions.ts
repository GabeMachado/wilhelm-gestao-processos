import { Role } from '@prisma/client';

export type PermissionKey =
  | 'VIEW_PROCESSES'
  | 'EDIT_PROCESSES'
  | 'DELETE_PROCESSES'
  | 'ADVANCE_FLOW'
  | 'MANAGE_FINANCE'
  | 'IMPORT_EXPORT'
  | 'MANAGE_TEAM'
  | 'VIEW_AUDIT';

export const PERMISSION_LABELS: Record<PermissionKey, string> = {
  VIEW_PROCESSES: 'Visualizar processos e dashboards',
  EDIT_PROCESSES: 'Criar e editar processos',
  DELETE_PROCESSES: 'Excluir processos',
  ADVANCE_FLOW: 'Avançar etapa e mover no Kanban',
  MANAGE_FINANCE: 'Gerenciar financeiro e honorários',
  IMPORT_EXPORT: 'Importar e exportar dados',
  MANAGE_TEAM: 'Gerenciar equipe e permissões',
  VIEW_AUDIT: 'Visualizar trilha de auditoria',
};

// Matches the permissions matrix in the design: Administrador, Advogado, Assistente, Financeiro
const MATRIX: Record<PermissionKey, Role[]> = {
  VIEW_PROCESSES: ['ADMIN', 'ADVOGADO', 'ASSISTENTE', 'FINANCEIRO'],
  EDIT_PROCESSES: ['ADMIN', 'ADVOGADO', 'ASSISTENTE'],
  DELETE_PROCESSES: ['ADMIN'],
  ADVANCE_FLOW: ['ADMIN', 'ADVOGADO', 'ASSISTENTE'],
  MANAGE_FINANCE: ['ADMIN', 'FINANCEIRO'],
  IMPORT_EXPORT: ['ADMIN', 'ADVOGADO', 'FINANCEIRO'],
  MANAGE_TEAM: ['ADMIN'],
  VIEW_AUDIT: ['ADMIN', 'FINANCEIRO'],
};

export const PERMISSION_ORDER: PermissionKey[] = [
  'VIEW_PROCESSES',
  'EDIT_PROCESSES',
  'DELETE_PROCESSES',
  'ADVANCE_FLOW',
  'MANAGE_FINANCE',
  'IMPORT_EXPORT',
  'MANAGE_TEAM',
  'VIEW_AUDIT',
];

export function can(role: Role, permission: PermissionKey): boolean {
  return MATRIX[permission].includes(role);
}

export function permissionsMatrix() {
  return PERMISSION_ORDER.map((key) => ({
    key,
    label: PERMISSION_LABELS[key],
    roles: MATRIX[key],
  }));
}
