import { Router } from 'express';
import multer from 'multer';
import ExcelJS from 'exceljs';
import { Etapa, MovimentacaoKind, Resultado, StatusProcesso } from '@prisma/client';
import { prisma } from '../db';
import { requireAuth, requirePermission } from '../auth';
import { PROXIMA_ACAO_POR_ETAPA, emeta, etapaIndex } from '../domain';

const router = Router();
router.use(requireAuth);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

const HEADER_ALIASES: Record<string, string[]> = {
  pasta: ['pasta', 'folder'],
  numero: ['número', 'numero', 'nº processo', 'processo'],
  cliente: ['cliente'],
  cnpj: ['cnpj', 'cpf/cnpj', 'cpf'],
  tipo: ['tipo'],
  tese: ['título', 'titulo', 'tese'],
  status: ['status'],
  fase: ['fase', 'status / fase', 'etapa'],
  valorCausa: ['valor da causa', 'valor causa'],
  valorHabilitado: ['valor habilitado'],
};

function normalizeHeader(h: string): string {
  return h.trim().toLowerCase();
}

function matchColumn(headers: string[], aliases: string[]): number {
  const normalized = headers.map(normalizeHeader);
  for (const alias of aliases) {
    const idx = normalized.indexOf(alias);
    if (idx >= 0) return idx;
  }
  return -1;
}

function mapStatusToEtapa(text: string): Etapa {
  const t = (text || '').toLowerCase();
  if (t.includes('encerr') || t.includes('arquiv')) return Etapa.ENCERRADO;
  if (t.includes('honor')) return Etapa.HONORARIOS;
  if (t.includes('compensa')) return Etapa.COMPENSACAO;
  if (t.includes('habilita') || t.includes('cálculo') || t.includes('calculo')) return Etapa.HABILITACAO;
  if (t.includes('procuraç') || t.includes('documento')) return Etapa.DOCUMENTOS;
  return Etapa.ENTRADA;
}

router.get('/import/template', requirePermission('IMPORT_EXPORT'), (_req, res) => {
  res.json({
    columns: Object.keys(HEADER_ALIASES).map((key) => ({ key, aliases: HEADER_ALIASES[key] })),
  });
});

router.post('/import', requirePermission('IMPORT_EXPORT'), upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado' });

  const workbook = new ExcelJS.Workbook();
  try {
    await workbook.xlsx.load(req.file.buffer as any);
  } catch {
    return res.status(400).json({ error: 'Não foi possível ler o arquivo. Envie um .xlsx válido.' });
  }
  const sheet = workbook.worksheets[0];
  if (!sheet) return res.status(400).json({ error: 'Planilha vazia' });

  // Real-world spreadsheets often have summary/title rows above the actual header —
  // scan the first rows for the one that contains a recognizable "Cliente" column.
  let headerRowNumber = -1;
  let headers: string[] = [];
  const maxScan = Math.min(sheet.rowCount, 20);
  for (let i = 1; i <= maxScan; i++) {
    const values = (sheet.getRow(i).values as any[]).map((v) => (v ? String(v) : ''));
    if (matchColumn(values, HEADER_ALIASES.cliente) >= 0) {
      headerRowNumber = i;
      headers = values;
      break;
    }
  }

  if (headerRowNumber < 0) {
    return res.status(400).json({ error: 'Coluna "Cliente" não encontrada na planilha' });
  }

  const col = {
    pasta: matchColumn(headers, HEADER_ALIASES.pasta),
    numero: matchColumn(headers, HEADER_ALIASES.numero),
    cliente: matchColumn(headers, HEADER_ALIASES.cliente),
    cnpj: matchColumn(headers, HEADER_ALIASES.cnpj),
    tipo: matchColumn(headers, HEADER_ALIASES.tipo),
    tese: matchColumn(headers, HEADER_ALIASES.tese),
    status: matchColumn(headers, HEADER_ALIASES.status),
    fase: matchColumn(headers, HEADER_ALIASES.fase),
    valorCausa: matchColumn(headers, HEADER_ALIASES.valorCausa),
    valorHabilitado: matchColumn(headers, HEADER_ALIASES.valorHabilitado),
  };

  const advogados = await prisma.user.findMany({ where: { role: 'ADVOGADO' } });
  if (advogados.length === 0) return res.status(400).json({ error: 'Nenhum advogado cadastrado para atribuir os processos' });

  const cell = (row: any[], idx: number) => (idx >= 0 ? row[idx] : undefined);
  const asString = (v: any) => (v === undefined || v === null ? '' : String(v).trim());
  const asNumber = (v: any) => {
    if (v === undefined || v === null || v === '') return 0;
    const n = Number(String(v).replace(/[^\d.,-]/g, '').replace(',', '.'));
    return Number.isFinite(n) ? n : 0;
  };

  let imported = 0;
  const existingCount = await prisma.processo.count();
  let rowOffset = 0;

  for (let i = headerRowNumber + 1; i <= sheet.rowCount; i++) {
    const row = sheet.getRow(i).values as any[];
    const clienteNome = asString(cell(row, col.cliente));
    if (!clienteNome) continue;

    const cnpj = asString(cell(row, col.cnpj)) || '—';
    const cidade = '—';
    const estado = 'SC';
    const cliente = await prisma.cliente.upsert({
      where: { nome_cnpjCpf: { nome: clienteNome, cnpjCpf: cnpj } },
      update: {},
      create: { nome: clienteNome, cnpjCpf: cnpj, cidade, estado },
    });

    const etapa = mapStatusToEtapa(asString(cell(row, col.fase)) + ' ' + asString(cell(row, col.status)));
    const adv = advogados[rowOffset % advogados.length];
    rowOffset++;

    await prisma.processo.create({
      data: {
        pasta: asString(cell(row, col.pasta)) || 'Proc - ' + String(2000 + existingCount + imported).padStart(7, '0'),
        numero: asString(cell(row, col.numero)) || '—',
        tipo: asString(cell(row, col.tipo)) || 'Mandado de Segurança',
        clienteId: cliente.id,
        contrario: 'Delegado da Receita Federal do Brasil',
        tese: asString(cell(row, col.tese)) || '—',
        teseTag: 'Tese',
        tribunal: '—',
        estado,
        cidade,
        advogadoId: adv.id,
        dataEntrada: new Date(),
        valorCausa: asNumber(cell(row, col.valorCausa)),
        valorHabilitado: asNumber(cell(row, col.valorHabilitado)),
        etapa,
        status: etapaIndex(etapa) >= 5 ? StatusProcesso.ARQUIVADO : StatusProcesso.ATIVO,
        resultado: etapaIndex(etapa) >= 5 ? Resultado.EXITO_TOTAL : Resultado.EM_ANDAMENTO,
        proximaAcao: PROXIMA_ACAO_POR_ETAPA[etapa],
        observacoes: 'Importado via planilha Excel.',
        movimentacoes: {
          create: {
            usuarioId: req.user!.sub,
            usuarioNome: req.user!.nome,
            acao: 'Processo importado',
            observacoes: 'Importado em lote via planilha Excel.',
            kind: MovimentacaoKind.CREATE,
          },
        },
      },
    }).catch(() => null);
    imported++;
  }

  res.json({ imported });
});

router.get('/export', requirePermission('IMPORT_EXPORT'), async (_req, res) => {
  const processos = await prisma.processo.findMany({ include: { cliente: true, advogado: true }, orderBy: { pasta: 'asc' } });
  const cols = ['Pasta', 'Numero', 'Tipo', 'Cliente', 'CNPJ', 'Tese', 'Etapa', 'Status', 'Responsavel', 'ValorCausa', 'ValorCredito', 'Prazo'];
  const escape = (v: any) => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const rows = processos.map((p) =>
    [
      p.pasta,
      p.numero,
      p.tipo,
      p.cliente.nome,
      p.cliente.cnpjCpf,
      p.tese,
      emeta(p.etapa).label,
      p.status,
      p.advogado.nome,
      p.valorCausa,
      p.valorCredito,
      p.prazo ? p.prazo.toISOString().slice(0, 10) : '',
    ]
      .map(escape)
      .join(';')
  );
  const csv = '﻿' + [cols.join(';')].concat(rows).join('\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="processos-wilhelm.csv"');
  res.send(csv);
});

export default router;
