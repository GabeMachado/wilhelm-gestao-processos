import { Router } from 'express';
import { Resultado } from '@prisma/client';
import { prisma } from '../db';
import { requireAuth } from '../auth';
import { EK, ETAPAS, daysBetween, emeta, etapaIndex } from '../domain';

const router = Router();
router.use(requireAuth);

const MES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

router.get('/', async (_req, res) => {
  const processos = await prisma.processo.findMany({ include: { cliente: true, advogado: true } });
  const now = new Date();
  const P = processos;

  const ativos = P.filter((p) => etapaIndex(p.etapa) < 5).length;
  const encerrados = P.filter((p) => etapaIndex(p.etapa) >= 5).length;
  const recuperado = P.reduce((a, p) => a + p.valorCompensado, 0);

  const metrics = [
    { label: 'Total de processos', value: P.length, icon: 'folder', color: '#5b8def', bg: 'rgba(91,141,239,.14)' },
    { label: 'Em andamento', value: ativos, icon: 'activity', color: '#e0a53a', bg: 'rgba(224,165,58,.14)' },
    { label: 'Encerrados', value: encerrados, icon: 'check-circle', color: '#35c28a', bg: 'rgba(53,194,138,.14)' },
    { label: 'Valor recuperado', value: recuperado, isMoney: true, icon: 'trending', color: 'var(--accent)', bg: 'var(--accent-bg)' },
  ];

  const cnt = (k: string) => P.filter((p) => p.etapa === k).length;
  const overdue = P.filter((p) => etapaIndex(p.etapa) < 5 && p.prazo && daysBetween(p.prazo, now) < 0).length;
  const pendencias = [
    { key: 'DOCUMENTOS', label: 'Pendentes de documentos', count: cnt('DOCUMENTOS'), icon: 'file', color: '#5b8def' },
    { key: 'HABILITACAO', label: 'Aguardando habilitação', count: cnt('HABILITACAO'), icon: 'gavel', color: '#8b7bd8' },
    { key: 'COMPENSACAO', label: 'Aguardando compensação', count: cnt('COMPENSACAO'), icon: 'receipt', color: '#3bc0c8' },
    { key: 'HONORARIOS', label: 'Honorários a receber', count: cnt('HONORARIOS'), icon: 'banknote', color: '#e0a53a' },
    { key: 'ENTRADA', label: 'Novos / entrada', count: cnt('ENTRADA'), icon: 'inbox', color: '#8b909c' },
    { key: '', label: 'Prazos vencidos', count: overdue, icon: 'alert', color: '#e5644e' },
  ];

  const maxE = Math.max(1, ...ETAPAS.map((e) => P.filter((p) => etapaIndex(p.etapa) >= etapaIndex(e.key)).length));
  const barEtapa = ETAPAS.map((e) => {
    const c = P.filter((p) => etapaIndex(p.etapa) >= etapaIndex(e.key)).length;
    return { label: e.label, count: c, pct: Math.round((c / maxE) * 100), color: e.color };
  });

  const rc: Record<string, number> = { EXITO_TOTAL: 0, EXITO_PARCIAL: 0, PERDA: 0, EM_ANDAMENTO: 0 };
  P.forEach((p) => (rc[p.resultado] = (rc[p.resultado] || 0) + 1));
  const RLABEL: Record<string, string> = { EXITO_TOTAL: 'Êxito Total', EXITO_PARCIAL: 'Êxito Parcial', PERDA: 'Perda', EM_ANDAMENTO: 'Em andamento' };
  const RCOLOR: Record<string, string> = { EXITO_TOTAL: '#35c28a', EXITO_PARCIAL: '#3bc0c8', PERDA: '#e5644e', EM_ANDAMENTO: '#8b909c' };
  const total = P.length || 1;
  const resultadoLegend = Object.keys(rc).map((k) => ({ label: RLABEL[k], count: rc[k], color: RCOLOR[k] }));
  const exitoPct = Math.round(((rc.EXITO_TOTAL + rc.EXITO_PARCIAL) / total) * 100);

  const buckets: { y: number; m: number; label: string; entradas: number; encerrados: number }[] = [];
  for (let m = 7; m >= 0; m--) {
    const d = new Date(now.getFullYear(), now.getMonth() - m, 1);
    buckets.push({ y: d.getFullYear(), m: d.getMonth(), label: MES[d.getMonth()], entradas: 0, encerrados: 0 });
  }
  P.forEach((p) => {
    const bE = buckets.find((b) => b.y === p.dataEntrada.getFullYear() && b.m === p.dataEntrada.getMonth());
    if (bE) bE.entradas++;
    if (p.etapa === 'ENCERRADO') {
      const bC = buckets.find((b) => b.y === p.updatedAt.getFullYear() && b.m === p.updatedAt.getMonth());
      if (bC) bC.encerrados++;
    }
  });
  const maxM = Math.max(1, ...buckets.map((b) => Math.max(b.entradas, b.encerrados)));
  const barMes = buckets.map((b) => ({
    label: b.label,
    entradas: b.entradas,
    encerrados: b.encerrados,
    hEnt: Math.max(4, Math.round((b.entradas / maxM) * 100)),
    hEnc: Math.max(2, Math.round((b.encerrados / maxM) * 100)),
  }));

  const advogados = await prisma.user.findMany({ where: { role: 'ADVOGADO' }, take: 4 });
  const respCount: Record<string, number> = {};
  advogados.forEach((a) => (respCount[a.nome] = 0));
  P.forEach((p) => {
    if (respCount[p.advogado.nome] !== undefined) respCount[p.advogado.nome]++;
  });
  const maxR = Math.max(1, ...Object.values(respCount));
  const barResp = advogados.map((a) => ({
    name: a.nome,
    initials: a.initials,
    color: a.color,
    bg: a.bg,
    count: respCount[a.nome] || 0,
    pct: Math.round(((respCount[a.nome] || 0) / maxR) * 100),
  }));

  const prazos = P.filter((p) => etapaIndex(p.etapa) < 5 && p.prazo)
    .map((p) => ({ p, dias: daysBetween(p.prazo as Date, now) }))
    .sort((a, b) => a.dias - b.dias)
    .slice(0, 6)
    .map(({ p, dias }) => ({
      pid: p.id,
      cliente: p.cliente.nome,
      acao: p.proximaAcao,
      prazo: p.prazo,
      dias,
    }));

  const recentMov = await prisma.movimentacao.findMany({
    orderBy: { data: 'desc' },
    take: 7,
    include: { processo: { include: { cliente: true } } },
  });
  const recentAtiv = recentMov.map((h) => ({
    kind: h.kind,
    user: h.usuarioNome,
    text: h.acao,
    cliente: h.processo.cliente.nome,
    when: h.data,
  }));

  res.json({ metrics, pendencias, barEtapa, resultadoLegend, exitoPct, barMes, barResp, prazos, recentAtiv });
});

export default router;
