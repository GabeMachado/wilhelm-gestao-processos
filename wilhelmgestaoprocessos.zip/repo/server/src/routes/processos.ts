import { Router } from 'express';
import { z } from 'zod';
import { Etapa, MovimentacaoKind, Resultado, StatusProcesso } from '@prisma/client';
import { prisma } from '../db';
import { requireAuth, requirePermission } from '../auth';
import { EK, PROXIMA_ACAO_POR_ETAPA, emeta, etapaIndex, nextEtapa } from '../domain';

const router = Router();
router.use(requireAuth);

const processoInclude = { cliente: true, advogado: true } as const;

function serialize(p: any) {
  return {
    id: p.id,
    pasta: p.pasta,
    numero: p.numero,
    tipo: p.tipo,
    cliente: p.cliente.nome,
    cnpj: p.cliente.cnpjCpf,
    cidade: p.cliente.cidade,
    estado: p.cliente.estado,
    contrario: p.contrario,
    tese: p.tese,
    teseTag: p.teseTag,
    tribunal: p.tribunal,
    adv: p.advogado.nome,
    advId: p.advogadoId,
    dataEntrada: p.dataEntrada,
    valorCausa: p.valorCausa,
    valorCredito: p.valorCredito,
    valorHabilitado: p.valorHabilitado,
    valorCompensado: p.valorCompensado,
    honContratual: p.honContratual,
    honSucumb: p.honSucumb,
    etapa: p.etapa,
    status: p.status,
    resultado: p.resultado,
    proximaAcao: p.proximaAcao,
    prazo: p.prazo,
    padm: p.padm,
    transito: p.transito,
    prescricao: p.prescricao,
    observacoes: p.observacoes,
    updatedAt: p.updatedAt,
  };
}

router.get('/', async (req, res) => {
  const { search, etapa, resp, tipo, status } = req.query as Record<string, string | undefined>;
  const where: any = {};
  if (etapa) where.etapa = etapa;
  if (tipo) where.tipo = tipo;
  if (status) where.status = status;
  if (resp) where.advogado = { nome: resp };
  if (search) {
    const q = search.trim();
    if (q) {
      where.OR = [
        { pasta: { contains: q, mode: 'insensitive' } },
        { numero: { contains: q, mode: 'insensitive' } },
        { tese: { contains: q, mode: 'insensitive' } },
        { cliente: { nome: { contains: q, mode: 'insensitive' } } },
        { cliente: { cnpjCpf: { contains: q, mode: 'insensitive' } } },
      ];
    }
  }
  const rows = await prisma.processo.findMany({ where, include: processoInclude, orderBy: { updatedAt: 'desc' } });
  res.json(rows.map(serialize));
});

const upsertSchema = z.object({
  cliente: z.string().min(1),
  cnpj: z.string().optional().default('—'),
  cidade: z.string().optional().default('—'),
  estado: z.string().optional().default('SC'),
  numero: z.string().optional().default('—'),
  tipo: z.string().min(1),
  advId: z.string().min(1),
  tese: z.string().optional().default('—'),
  tribunal: z.string().optional().default('—'),
  etapa: z.nativeEnum(Etapa).optional().default('ENTRADA'),
  dataEntrada: z.string().optional(),
  proximaAcao: z.string().optional().default('—'),
  prazo: z.string().optional().nullable(),
  valorCausa: z.coerce.number().optional().default(0),
  valorCredito: z.coerce.number().optional().default(0),
  observacoes: z.string().optional().default(''),
});

router.post('/', requirePermission('EDIT_PROCESSES'), async (req, res) => {
  const parsed = upsertSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Dados inválidos' });
  const f = parsed.data;

  const cliente = await prisma.cliente.upsert({
    where: { nome_cnpjCpf: { nome: f.cliente, cnpjCpf: f.cnpj || '—' } },
    update: { cidade: f.cidade, estado: f.estado },
    create: { nome: f.cliente, cnpjCpf: f.cnpj || '—', cidade: f.cidade || '—', estado: f.estado || 'SC' },
  });

  const count = await prisma.processo.count();
  const pasta = 'Proc - ' + String(2000 + count).padStart(7, '0');
  const ei = etapaIndex(f.etapa);

  const processo = await prisma.processo.create({
    data: {
      pasta,
      numero: f.numero || '—',
      tipo: f.tipo,
      clienteId: cliente.id,
      contrario: 'Delegado da Receita Federal do Brasil',
      tese: f.tese || '—',
      teseTag: 'Tese',
      tribunal: f.tribunal || '—',
      estado: f.estado || 'SC',
      cidade: f.cidade || '—',
      advogadoId: f.advId,
      dataEntrada: f.dataEntrada ? new Date(f.dataEntrada) : new Date(),
      valorCausa: f.valorCausa,
      valorCredito: f.valorCredito,
      valorHabilitado: ei >= 2 ? f.valorCredito : 0,
      etapa: f.etapa,
      status: ei >= 5 ? StatusProcesso.ARQUIVADO : StatusProcesso.ATIVO,
      resultado: ei >= 5 ? Resultado.EXITO_TOTAL : Resultado.EM_ANDAMENTO,
      proximaAcao: f.proximaAcao || '—',
      prazo: f.prazo ? new Date(f.prazo) : null,
      observacoes: f.observacoes || '—',
      movimentacoes: {
        create: {
          usuarioId: req.user!.sub,
          usuarioNome: req.user!.nome,
          acao: 'Processo cadastrado',
          observacoes: 'Cadastro manual no sistema.',
          kind: MovimentacaoKind.CREATE,
        },
      },
    },
    include: processoInclude,
  });
  res.status(201).json(serialize(processo));
});

router.get('/:id', async (req, res) => {
  const p = await prisma.processo.findUnique({ where: { id: req.params.id }, include: processoInclude });
  if (!p) return res.status(404).json({ error: 'Processo não encontrado' });
  const historico = await prisma.movimentacao.findMany({
    where: { processoId: p.id },
    orderBy: { data: 'desc' },
  });
  res.json({ ...serialize(p), historico });
});

router.patch('/:id', requirePermission('EDIT_PROCESSES'), async (req, res) => {
  const parsed = upsertSchema.partial({ cliente: true, tipo: true, advId: true }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Dados inválidos' });
  const f = parsed.data;
  const existing = await prisma.processo.findUnique({ where: { id: req.params.id }, include: processoInclude });
  if (!existing) return res.status(404).json({ error: 'Processo não encontrado' });

  let clienteId = existing.clienteId;
  if (f.cliente) {
    const cliente = await prisma.cliente.upsert({
      where: { nome_cnpjCpf: { nome: f.cliente, cnpjCpf: f.cnpj || existing.cliente.cnpjCpf } },
      update: { cidade: f.cidade ?? existing.cliente.cidade, estado: f.estado ?? existing.cliente.estado },
      create: {
        nome: f.cliente,
        cnpjCpf: f.cnpj || existing.cliente.cnpjCpf,
        cidade: f.cidade || existing.cliente.cidade,
        estado: f.estado || existing.cliente.estado,
      },
    });
    clienteId = cliente.id;
  }

  const ei = f.etapa ? etapaIndex(f.etapa) : etapaIndex(existing.etapa);
  const updated = await prisma.processo.update({
    where: { id: existing.id },
    data: {
      clienteId,
      numero: f.numero ?? existing.numero,
      tipo: f.tipo ?? existing.tipo,
      tese: f.tese ?? existing.tese,
      tribunal: f.tribunal ?? existing.tribunal,
      advogadoId: f.advId ?? existing.advogadoId,
      dataEntrada: f.dataEntrada ? new Date(f.dataEntrada) : existing.dataEntrada,
      etapa: f.etapa ?? existing.etapa,
      status: ei >= 5 ? StatusProcesso.ARQUIVADO : StatusProcesso.ATIVO,
      proximaAcao: f.proximaAcao ?? existing.proximaAcao,
      prazo: f.prazo !== undefined ? (f.prazo ? new Date(f.prazo) : null) : existing.prazo,
      valorCausa: f.valorCausa ?? existing.valorCausa,
      valorCredito: f.valorCredito ?? existing.valorCredito,
      observacoes: f.observacoes ?? existing.observacoes,
      movimentacoes: {
        create: {
          usuarioId: req.user!.sub,
          usuarioNome: req.user!.nome,
          acao: 'Processo editado',
          observacoes: 'Dados atualizados manualmente.',
          kind: MovimentacaoKind.EDIT,
        },
      },
    },
    include: processoInclude,
  });
  res.json(serialize(updated));
});

router.delete('/:id', requirePermission('DELETE_PROCESSES'), async (req, res) => {
  const existing = await prisma.processo.findUnique({ where: { id: req.params.id } });
  if (!existing) return res.status(404).json({ error: 'Processo não encontrado' });
  await prisma.processo.delete({ where: { id: existing.id } });
  res.json({ ok: true });
});

router.post('/:id/advance', requirePermission('ADVANCE_FLOW'), async (req, res) => {
  const existing = await prisma.processo.findUnique({ where: { id: req.params.id }, include: processoInclude });
  if (!existing) return res.status(404).json({ error: 'Processo não encontrado' });
  const next = nextEtapa(existing.etapa);
  if (!next) return res.status(400).json({ error: 'Processo já está encerrado' });

  const updated = await prisma.processo.update({
    where: { id: existing.id },
    data: {
      etapa: next,
      status: etapaIndex(next) >= 5 ? StatusProcesso.ARQUIVADO : StatusProcesso.ATIVO,
      resultado: etapaIndex(next) >= 5 ? Resultado.EXITO_TOTAL : existing.resultado,
      proximaAcao: PROXIMA_ACAO_POR_ETAPA[next],
      prazo: etapaIndex(next) >= 5 ? null : existing.prazo,
      movimentacoes: {
        create: {
          usuarioId: req.user!.sub,
          usuarioNome: req.user!.nome,
          acao: 'Etapa concluída · ' + emeta(existing.etapa).label,
          observacoes: 'Avançado para: ' + emeta(next).label,
          kind: MovimentacaoKind.DONE,
        },
      },
    },
    include: processoInclude,
  });
  res.json(serialize(updated));
});

const moveSchema = z.object({ etapa: z.nativeEnum(Etapa) });

router.post('/:id/move', requirePermission('ADVANCE_FLOW'), async (req, res) => {
  const parsed = moveSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Etapa inválida' });
  const existing = await prisma.processo.findUnique({ where: { id: req.params.id } });
  if (!existing) return res.status(404).json({ error: 'Processo não encontrado' });
  if (existing.etapa === parsed.data.etapa) return res.json(serialize(existing));

  const updated = await prisma.processo.update({
    where: { id: existing.id },
    data: {
      etapa: parsed.data.etapa,
      status: etapaIndex(parsed.data.etapa) >= 5 ? StatusProcesso.ARQUIVADO : StatusProcesso.ATIVO,
      resultado: etapaIndex(parsed.data.etapa) >= 5 ? Resultado.EXITO_TOTAL : existing.resultado,
      movimentacoes: {
        create: {
          usuarioId: req.user!.sub,
          usuarioNome: req.user!.nome,
          acao: 'Movido no Kanban → ' + emeta(parsed.data.etapa).label,
          observacoes: 'Etapa alterada via arrastar e soltar.',
          kind: MovimentacaoKind.MOVE,
        },
      },
    },
    include: processoInclude,
  });
  res.json(serialize(updated));
});

export default router;
