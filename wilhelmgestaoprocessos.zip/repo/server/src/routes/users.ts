import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { Role } from '@prisma/client';
import { prisma } from '../db';
import { requireAuth, requirePermission } from '../auth';
import { permissionsMatrix } from '../permissions';

const router = Router();
router.use(requireAuth);

const ROLE_META: Record<Role, { label: string; color: string; bg: string; desc: string }> = {
  ADMIN: { label: 'Administrador', color: '#d6a52a', bg: 'rgba(214,165,42,.14)', desc: 'Acesso total ao sistema' },
  ADVOGADO: { label: 'Advogado', color: '#5b8def', bg: 'rgba(91,141,239,.14)', desc: 'Gestão de processos e fluxo' },
  ASSISTENTE: { label: 'Assistente', color: '#8b7bd8', bg: 'rgba(139,123,216,.14)', desc: 'Apoio operacional e cadastros' },
  FINANCEIRO: { label: 'Financeiro', color: '#35c28a', bg: 'rgba(53,194,138,.14)', desc: 'Honorários e compensações' },
};
const ROLE_ORDER: Role[] = ['ADMIN', 'ADVOGADO', 'ASSISTENTE', 'FINANCEIRO'];

router.get('/', async (_req, res) => {
  const users = await prisma.user.findMany({ orderBy: { createdAt: 'asc' } });
  const withCounts = await Promise.all(
    users.map(async (u) => ({
      id: u.id,
      nome: u.nome,
      email: u.email,
      role: u.role,
      roleLabel: ROLE_META[u.role].label,
      roleColor: ROLE_META[u.role].color,
      roleBg: ROLE_META[u.role].bg,
      initials: u.initials,
      color: u.color,
      bg: u.bg,
      online: u.online,
      count: await prisma.processo.count({ where: { advogadoId: u.id } }),
    }))
  );
  const roles = ROLE_ORDER.map((r) => ({
    key: r,
    label: ROLE_META[r].label,
    color: ROLE_META[r].color,
    bg: ROLE_META[r].bg,
    desc: ROLE_META[r].desc,
    count: users.filter((u) => u.role === r).length,
  }));
  res.json({ team: withCounts, roles, teamCount: users.length });
});

router.get('/permissions', (_req, res) => {
  const roles = ROLE_ORDER.map((r) => ({ key: r, label: ROLE_META[r].label, color: ROLE_META[r].color }));
  res.json({ roles, rows: permissionsMatrix() });
});

const inviteSchema = z.object({
  nome: z.string().min(1),
  email: z.string().email(),
  role: z.nativeEnum(Role),
});

router.post('/', requirePermission('MANAGE_TEAM'), async (req, res) => {
  const parsed = inviteSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Dados inválidos' });
  const { nome, email, role } = parsed.data;
  const initials = nome
    .split(' ')
    .filter((w) => w.length > 2 || w === w.toUpperCase())
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('') || nome.slice(0, 2).toUpperCase();
  const tempPassword = Math.random().toString(36).slice(2, 10);
  const passwordHash = await bcrypt.hash(tempPassword, 10);
  const user = await prisma.user.create({
    data: { nome, email, role, initials, color: ROLE_META[role].color, bg: ROLE_META[role].bg, passwordHash },
  });
  res.status(201).json({ id: user.id, nome: user.nome, email: user.email, role: user.role, tempPassword });
});

export default router;
