import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '../db';
import { COOKIE_NAME, requireAuth, signToken } from '../auth';

const router = Router();

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post('/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'E-mail e senha são obrigatórios' });
  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Credenciais inválidas' });

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Credenciais inválidas' });

  const token = signToken({ sub: user.id, role: user.role, nome: user.nome, email: user.email });
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
  await prisma.user.update({ where: { id: user.id }, data: { online: true } });
  res.json({
    id: user.id,
    nome: user.nome,
    email: user.email,
    role: user.role,
    initials: user.initials,
    color: user.color,
    bg: user.bg,
  });
});

router.post('/logout', requireAuth, async (req, res) => {
  await prisma.user.update({ where: { id: req.user!.sub }, data: { online: false } }).catch(() => {});
  res.clearCookie(COOKIE_NAME);
  res.json({ ok: true });
});

router.get('/me', requireAuth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.sub } });
  if (!user) return res.status(401).json({ error: 'Sessão inválida' });
  res.json({
    id: user.id,
    nome: user.nome,
    email: user.email,
    role: user.role,
    initials: user.initials,
    color: user.color,
    bg: user.bg,
  });
});

export default router;
