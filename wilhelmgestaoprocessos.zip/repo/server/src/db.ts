import { PrismaClient } from '@prisma/client';

// Reuse the client across warm serverless invocations (and dev hot-reloads)
// instead of opening a fresh pool of connections every time this module loads.
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma = global.__prisma ?? new PrismaClient();
global.__prisma = prisma;
