# Deploy: GitHub → Supabase → Vercel

This app is structured to deploy as a single Vercel project: the React app
builds to static files, and the Express API runs as one Vercel serverless
function (`api/index.ts`) that all `/api/*` requests are rewritten to (see
`vercel.json`). Postgres runs on Supabase.

## 1. Push to GitHub

```
git remote add origin <your-repo-url>
git push -u origin main
```

## 2. Create the Supabase project (database)

1. Go to [supabase.com](https://supabase.com) → **New project**.
2. Pick a name/region and a database password (save it).
3. Once it's provisioned, go to **Project Settings → Database**.
4. Under **Connection string**, copy two values:
   - **Transaction pooler** (port `6543`, includes `?pgbouncer=true`) → this is `DATABASE_URL`.
   - **Direct connection** (port `5432`) → this is `DIRECT_URL`.

## 3. Run migrations + seed against Supabase

From your machine, with the repo checked out:

```
cd server
cp .env.example .env
# paste the two Supabase connection strings into .env as DATABASE_URL / DIRECT_URL
npm install
npx prisma migrate deploy
npx tsx prisma/seed.ts
```

This creates the schema and seeds the same 32 demo processes / 6 users used
in local dev (login: any seeded e-mail, password `senha-demo` — **change
this in Supabase directly, or re-seed with different passwords, before
using this for real data**).

## 4. Create the Vercel project

1. Go to [vercel.com/new](https://vercel.com/new) and import the GitHub repo.
2. Vercel should detect the root `vercel.json` — leave **Root Directory** as
   the repo root (do *not* set it to `client`, since the API function lives
   at the repo root under `api/`).
3. Framework preset: **Other** (the build/output are already defined in
   `vercel.json`).

## 5. Environment variables (Vercel project → Settings → Environment Variables)

| Name | Value |
|---|---|
| `DATABASE_URL` | Supabase pooled connection string |
| `DIRECT_URL` | Supabase direct connection string |
| `JWT_SECRET` | a long random string (not the dev placeholder) |

`CLIENT_ORIGIN` is not needed in this unified deployment — frontend and API
share the same domain, so there's no cross-origin request to configure.

## 6. Deploy

Click **Deploy**. Vercel will run `npm run vercel-build` (generates the
Prisma client, builds the client app) and deploy `api/index.ts` as the
serverless function.

## Known limitation: bulk import on serverless

The Excel import (`POST /api/import`) processes rows sequentially and, for a
large real-world spreadsheet (~2000 rows), took ~20–30s locally. Vercel's
**Hobby plan caps function execution at 10 seconds** (not configurable) — a
big import will likely time out there. On a **Pro plan** you can raise the
limit by adding to `vercel.json`:

```json
"functions": { "api/index.ts": { "maxDuration": 60 } }
```

For anything larger than that, the import route would need to be reworked
into a background job (e.g. queue + polling) rather than a single request —
not implemented here since it wasn't part of the original design's scope.
